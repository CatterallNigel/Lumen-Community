# Lumen M0.1 --- Runtime Configuration, Pi Provider Abstraction and Dockerisation Plan

**Date:** 2026-09-16\
**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)
**Scope:** Phase 11 implementation refinement for the M0.1 External
Research Distribution


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## 1. Purpose

This document consolidates the current design decisions for preparing
Lumen M0.1 for external research distribution.

The work is deliberately split into independently testable increments.
The objective is to preserve the existing Lumen architecture and Servire
lifecycle model while introducing only the distribution-specific changes
that are actually required.

There are three principal areas of work:

1.  **Servire-owned external connection configuration**, beginning with
    Ollama.
2.  **Pontis tool-provider abstraction**, with Pi as the only currently
    supported/default provider but not permanently hard-coded as the
    only possible provider.
3.  **Dockerisation of Lumen**, performed incrementally before adding
    HAProxy and the distribution MongoDB instance.

The central implementation principle is:

> **Do not redesign working Lumen service lifecycles merely to fit
> Docker. Package the existing architecture so that Servire remains the
> Lumen process supervisor.**

------------------------------------------------------------------------

## 2. Agreed M0.1 Runtime Topology

The intended final M0.1 topology is:

``` text
                    External Client
                          |
                          | host/IP + Pontis port
                          v
                    Lumen Host IP
                          |
                     +----+----+
                     | HAProxy |
                     |container|
                     +----+----+
                       /       \
      host/IP +       /         \       host/IP +
      Servire port   v           v       Pontis port
                 Servire       Pontis
                                  |
                                  v
                              Vestigare

                 +--------------------+
                 |  LUMEN CONTAINER   |
                 |                    |
                 |  tini / init       |
                 |       |            |
                 |    Servire         |
                 |       |            |
                 |       +-- Pontis --+--> pi-acp / Pi
                 |       |               (internal Rogare tools)
                 |       +-- Praebere +------------------> external Ollama
                 |       +-- Moderari +------------------> external Ollama
                 |       +-- Repetere |
                 |       +-- Vestigare|
                 |       +-- Rogare   |
                 |       +-- Fiducia  |
                 |       +-- Nuntius  |
                 +----------+---------+
                            |
                            v
                   +----------------+
                   |    MongoDB     |
                   |   container    |
                   |     :27017     |
                   +----------------+
```

The external client is outside the Lumen host. An independently running
Pi may be such a client and reaches Pontis using the Lumen host/IP and
Pontis port. This is distinct from the Pi/`pi-acp` child process
packaged inside the Lumen application container for Rogare tool use.

Ollama remains **external to the Lumen distribution**. It may physically
be a native host process, another Docker container, or a service on
another machine. From Lumen's architectural perspective it is simply an
externally configured model-provider endpoint.

MongoDB remains in its **own container**.

The Compose distribution creates and owns a **dedicated private Lumen
Docker network** shared by the HAProxy container, the Lumen application
container and the MongoDB container. Container-to-container traffic uses
this network and Docker service-name resolution rather than relying on
container IP addresses. Ollama and Illuminates.One remain external to
this Docker network. Licentia is internal to the Lumen runtime and is the
only Lumen service that communicates with Illuminates.One for authorization.

HAProxy remains in its **own container**, is attached to the Lumen
Docker network, and becomes the sole external application ingress to
Lumen. **M0.1 exposes Servire and Pontis through separate HAProxy
listeners identified by host/IP and port. HAProxy forwards each listener
across the Lumen Docker network to the corresponding service inside the
Lumen application container. Path-based routing is not required.**

------------------------------------------------------------------------

# Part I --- Servire-Owned External Infrastructure Configuration

## 3. Architectural Principle

The longer-term architectural direction is:

> **Servire is the authoritative owner of external infrastructure
> connection information and credentials. Services receive the
> connection information they require through Nuntius `\obt` control
> messages rather than independently maintaining authoritative copies.**

This principle applies to ordinary external runtime infrastructure
configuration such as Ollama. **Authorization is explicitly outside this
control-plane pattern.** Authorization must not be transported through
Nuntius or `\obt`; the dedicated Licentia service brokers the external
Illuminates.One exchange, while Servire independently verifies the
cryptographic authorization proof.

This separates two responsibilities:

-   A service's `config.yaml` describes **how the service behaves**.
-   Servire describes **where external deployment infrastructure is and
    how it is accessed**.

Ultimately this should include Ollama, MongoDB and any future external
infrastructure or providers.

For M0.1 this principle is introduced only where required rather than
migrating every existing connection immediately.

------------------------------------------------------------------------

## 4. M0.1 Ollama Ownership and Servire UI

For M0.1, Servire is authoritative for the Ollama endpoint.

The same endpoint is consumed for distinct purposes:

-   **Praebere** owns model/provider discovery and model lifecycle.
-   **Moderari** owns model inference/completion requests.

Sharing the Servire-owned endpoint must not blur those responsibilities.

### 4.1 External Dependencies

Pi should be removed from Servire's **External Dependencies**. Pi and
`pi-acp` are part of the Lumen runtime and are launched through Pontis.

Ollama should instead appear alongside MongoDB:

``` text
External Dependencies

Ollama
    Host:  [ localhost ]
    Port:  [ 11434     ]   [ Apply ]
    State: available / unavailable / not verified

MongoDB
    State: available / unavailable
```

`localhost:11434` remains the researcher-facing default.

Before stack startup, the researcher may edit the endpoint and select
**Apply**. MongoDB is already a mandatory Servire bootstrap dependency
by the time the normal operational UI is available. Apply updates
Servire's in-memory Ollama endpoint and persists it immediately to
MongoDB. Apply invalidates any previous Verify state and disables Start
until Verify succeeds again. It means:

> **Use this as Servire's proposed in-memory Ollama configuration.**

Once the stack has started, the Ollama Host/Port and Apply controls are
disabled for M0.1.

For Docker, researcher-facing `localhost` must be translated internally
to the Docker host when required. Remote hostnames/IP addresses remain
unchanged.

### 4.2 Apply Invalidates Validation

Changing the endpoint and selecting Apply invalidates any previous
successful Servire validation and disables Start until Verify succeeds
again:

``` text
READY TO START
      |
edit endpoint
      |
    Apply
      |
      +--> proposed endpoint updated in memory
      +--> previous validation invalidated
      +--> Start disabled
      |
    Verify required again
```

------------------------------------------------------------------------

### 4.1 MongoDB as a Servire bootstrap dependency

MongoDB is a **mandatory bootstrap dependency for Servire becoming
operational**. It is not, however, a prerequisite for the Servire web
process itself to start.

Servire startup therefore follows this sequence:

``` text
Servire process starts
        |
        v
Load Servire config.yaml
        |
        v
Attempt MongoDB connection
        |
        +-- FAILED
        |      |
        |      v
        |   Servire UI remains available
        |   Servire tab reports:
        |
        |     MongoDB is unavailable
        |     Connection failed using: mongodb:27017
        |
        |   Verify / Start unavailable
        |   Other component tabs remain visible
        |   and retain their normal Unavailable state
        |
        +-- SUCCESS
               |
               v
        Read persisted external configuration
        including the Ollama endpoint
               |
               v
        Enter normal Servire operational UI
```

Failure to connect to MongoDB must therefore **not** prevent the Servire
UI from being served. Instead, Servire remains in a restricted
bootstrap-failure state.

The Servire tab should use the same visual language already used for
unavailable Lumen components. A suitable presentation is:

``` text
MongoDB is unavailable

Lumen Servire could not establish its required MongoDB connection.
Connection failed using: mongodb:27017

Check that the Lumen MongoDB service is running and available.

[ Retry ]
```

The displayed connection information must be limited to useful,
non-secret endpoint information. **Passwords, credentials and other
secrets must never be rendered in the failure message.**

The remaining Servire tabs stay visible. Because the managed Lumen
services have not been started, those tabs continue to display their
existing normal **Unavailable** state. No separate bootstrap-error
application or alternative component UI is required.

While MongoDB is unavailable:

-   the normal Servire operational state is not entered;
-   Verify is unavailable;
-   Start is unavailable;
-   no managed Lumen services are started;
-   Servire remains available to explain the dependency failure.

Once MongoDB is available and Servire has successfully connected,
Servire reads the persisted Ollama endpoint from MongoDB. If no
persisted endpoint exists, it uses the default Ollama endpoint from
Servire `config.yaml`. The normal UI then displays the authoritative
endpoint and the usual Apply -\> Verify -\> Start workflow becomes
available.

This distinction is an M0.1 acceptance requirement:

> **MongoDB is Servire's mandatory bootstrap dependency. Failure to
> connect to MongoDB does not prevent the Servire web process or UI from
> starting. It prevents Servire from entering its normal operational
> state or starting the Lumen service stack.**

### 4.2 Servire participation in the Nuntius control plane

Servire is not only the M0.1 process supervisor and operator UI. Because
it owns authoritative external runtime configuration, it must also
participate as a recognised service in the existing Nuntius control
plane.

Servire must **declare/register itself with Nuntius** using the same
service declaration and routing conventions already used by other Lumen
services. This allows Servire to originate and receive the `\obt`
control messages required to distribute authoritative runtime
configuration.

The implementation must not introduce a Servire-specific side channel.
During implementation, the existing Nuntius declaration, registration,
routing and response/acknowledgement mechanisms must be inspected and
reused.

Acceptance requires that Nuntius recognises Servire as a valid Lumen
service identity, Servire-originated `\obt` messages route to their
intended services, responses/acknowledgements return correctly to
Servire, and existing service-to-service `\obt` traffic remains
unaffected.

The exact message schema and ordering for the new runtime-configuration
commands remain implementation details to be confirmed from the current
code rather than invented in this plan.

## 5. Verify, Persistence and Ollama Availability

MongoDB is required for Servire to persist the authoritative Ollama
endpoint, but is **not** required merely to edit and Apply a proposed
endpoint.

The lifecycle is:

``` text
Servire starts
      |
      +--> proposed Ollama endpoint in memory
      |      +--> persisted value if available
      |      +--> otherwise localhost:11434
      |
      +--> researcher may edit + Apply
      |
    Verify
      |
      +--> verify MongoDB
      |      +--> failure -> validation fails
      |
      +--> verify proposed Ollama endpoint
      |      +--> failure -> Ollama unavailable / validation fails
      |
      +--> persist verified Ollama endpoint to MongoDB
      |
      +--> remaining validation checks
      |
      v
READY TO START
```

There is no separate Praebere-based **Test Connection** control.

For the default endpoint, the researcher changes nothing and simply
selects Verify. For a non-default endpoint the flow is:

``` text
edit -> Apply -> Verify
```

Successful Verify requires MongoDB to remain available, the configured
Ollama endpoint to pass Servire's lightweight reachability check, and
all other required Servire validation checks to pass. This check does
**not** establish that Ollama itself is operational as a model provider.
Praebere performs the authoritative Ollama/provider validation,
reconciliation and model discovery during Lumen startup.

The verified Ollama endpoint is persisted by Servire in MongoDB, so a
non-default endpoint survives subsequent Servire restarts.

The exact Servire persistence document/collection should be selected
during implementation from the existing persistence model.

------------------------------------------------------------------------

## 6. Praebere and Moderari Runtime Ollama Configuration

Praebere and Moderari must no longer establish Ollama connectivity as a
prerequisite of their process startup.

Instead, they start to their normal operational/control state and
receive the already-verified authoritative Ollama endpoint from Servire
through the existing Nuntius `\obt` control plane.

> **Servire owns where Ollama is. Praebere owns model/provider discovery
> and lifecycle. Moderari owns model inference.**

### 6.1 Praebere Startup

``` text
Servire starts Praebere
        |
Praebere reaches operational control state
without attempting Ollama startup connectivity
        |
Servire sends verified Ollama endpoint via \obt
        |
Praebere adopts endpoint
        |
connects / reconciles / discovers models
        |
        +--> success -> report success to Servire; startup continues
        |
        +--> failure -> report failure to Servire
                        |
                        +--> Servire rolls back startup
```

Verify's lightweight availability check is not a replacement for this
provider-level operation. Praebere must prove that Lumen can establish
and reconcile its model-provider state against the endpoint.

### 6.2 Moderari Startup

Moderari likewise starts without requiring Ollama connectivity from a
locally authoritative endpoint. Servire supplies the same verified
endpoint through `\obt` for inference:

``` text
Servire
   |
   +-- \obt --> Praebere --> Ollama
   |             discovery / lifecycle
   |
   +-- \obt --> Moderari --> Ollama
                 inference
```

### 6.3 Changing Ollama After Validation

Before stack startup, a new Apply invalidates validation and requires
Verify again.

While the stack is running, the Ollama input fields and Apply control
are disabled. Changing provider therefore requires:

``` text
Stop stack -> edit -> Apply -> Verify -> Start stack
```

Live Ollama/provider migration is outside M0.1.

The exact `\obt` schemas and acknowledgement semantics should be defined
after inspection of the existing Praebere, Moderari and Nuntius control
paths.

------------------------------------------------------------------------

## 7. MongoDB Configuration for M0.1

MongoDB is deliberately **not migrated to Servire-owned configuration in
M0.1**.

The M0.1 distribution will use:

``` text
0.0.0.0:27018 -> MongoDB container :27017
```

This permits MongoDB Compass, research scripts or other tooling to
connect from another machine when the host firewall/network permits it.

MongoDB authentication will be enabled.

For M0.1 the MongoDB username/password should be **fixed distribution
credentials** and used consistently by the MongoDB container and all
Lumen services.

They should be documented as:

> **Fixed for M0.1 --- do not change.**

Although the values may necessarily be visible in distribution
configuration, they prevent anonymous MongoDB access. They are not
treated as equivalent to cryptographic installation identity secrets.

Allowing the researcher to change them in M0.1 would require
distributing the new connection credentials to multiple services, which
is precisely the architectural problem the future Servire
infrastructure-authority work is intended to solve.

### Future direction

After M0.1:

``` text
Servire
   |
   | authoritative Mongo endpoint + credentials
   |
   +---- \obt ---> Vestigare
   +---- \obt ---> Repetere
   +---- \obt ---> other consumers
```

MongoDB location and credentials can then become genuinely configurable.

------------------------------------------------------------------------

# Part II --- Pontis Tool-Provider Abstraction

## 8. Current Position

For M0.1, **Pi is the only supported tool provider for Rogare/Pontis**.

However, Pi should be treated as:

> **the currently supported and default tool provider**

rather than:

> **the permanently hard-coded tool architecture of Pontis.**

This distinction should be introduced now while the Docker/Pi
integration is being changed.

------------------------------------------------------------------------

## 9. M0.1 Tool Availability and Future Provider Framework

Pontis already receives the tool-enabled/tool-disabled execution state
used by Rogare. No additional externally visible tool-selection control
is introduced for M0.1.

Conceptually:

``` text
Rogare
   |
   | existing tools_enabled state
   v
Pontis
   |
   +---- tools_enabled = false
   |       |
   |       +---- no tool provider required
   |
   +---- tools_enabled = true       [normal/default]
           |
           +---- tool-provider abstraction
                    |
                    +---- Pi / ACP   [only M0.1 implementation]
```

For M0.1, tools-enabled operation remains the normal/default use and Pi
is the only supported tool provider. The existing Rogare no-tools
behaviour continues to work through Pontis, but no new external Pontis
control or provider selector is required.

The purpose of the M0.1 work is therefore to establish the framework
boundary, not to design the future provider system. Pontis must separate
the concept of **tool availability** from the specific **Pi provider
implementation**, so that Pi does not become a permanent architectural
dependency.

Future versions may introduce additional tool providers and transports.
ACP-based providers are a likely extension path. MCP or other mechanisms
may also be considered later. Their architecture is intentionally not
defined by M0.1.

------------------------------------------------------------------------

## 10. Pi in the Lumen Container

Pi and `pi-acp` should be installed **inside the Lumen application
container**.

Pontis should continue to use the existing architectural model:

``` text
Pontis
   |
   | launches child process
   v
pi-acp
   |
   v
Pi
```

ACP remains stdin/stdout process communication. We should not create a
Pi network service simply because Lumen is being Dockerised.

The existing Windows configuration currently points at a Windows npm
shim such as:

``` text
C:/Users/.../npm/pi-acp.cmd
```

The Linux distribution will instead use the Linux `pi-acp` executable
available inside the container.

------------------------------------------------------------------------

## 11. Pontis Provider Behaviour --- No M0.1 Redesign

The existing Pontis/Pi provider behaviour remains as it is for M0.1.

Dockerisation does **not** introduce a new Pontis provider abstraction,
provider-discovery mechanism, provider selector, or other tool-provider
redesign. The work is limited to making the existing Pontis/Pi
relationship operate correctly in Linux Docker.

Future ACP providers, MCP, or other mechanisms remain outside M0.1.

------------------------------------------------------------------------

## 12. Pontis/Pi Initial Lumen Container and Substitution Test

This is both the first Docker technical proof **and the beginning of the
actual M0.1 Lumen application image**. It is not a throw-away spike.

The image/Dockerfile created here should be retained and expanded in
later stages until it becomes the complete Lumen application container.

The initial proof should use the existing development Lumen stack rather
than an isolated synthetic test harness.

The normal development stack is started through Servire. The native
development Pontis is then stopped and temporarily replaced by a Linux
Docker container containing only Pontis, Pi and `pi-acp`.

For this test only, Pontis retains its normal externally visible host
port so the rest of Lumen continues to address Pontis exactly as it does
today:

``` text
Existing development stack

Rogare / other callers
        |
        | 127.0.0.1:11435
        v
Docker published port 11435
        |
        v
+--------------------------+
| Pontis test container    |
|                          |
| Pontis                   |
|   |                      |
|   +----> pi-acp -> Pi    |
+-------------+------------+
              |
              | normal Pontis calls to existing
              | host-running Lumen services
              v
        Vestigare / etc.
```

Pontis must listen on an interface inside the container that permits the
Docker published port to reach it.

For Pontis-initiated calls to existing host-running Lumen services, the
development machine's network IP may be used so the same endpoint is
usable from both native and Docker Pontis. Any such host service must be
listening on the corresponding host network interface rather than only
loopback. This is a property of the service HTTP server's bind/listen
configuration, not of Docker.

Pi does **not** communicate directly with Ollama. Pi communicates with
Pontis through ACP. Pontis continues to participate in the normal Lumen
request/response and trace paths; model traffic reaches Ollama through
the existing Lumen architecture.

The substitution test should establish that:

1.  Pi and `pi-acp` can be installed reliably in Linux Docker.
2.  The expected Linux executables are available.
3.  Pontis can spawn `pi-acp`.
4.  ACP stdin/stdout communication works.
5.  A real ACP session can be established.
6.  The existing Rogare UI can conduct a normal chat through Dockerised
    Pontis.
7.  A real Pi tool operation can execute successfully.
8.  Containerised Pontis can communicate with the existing host-running
    Lumen services required for its normal execution path.
9.  Pontis can terminate the Pi child cleanly when the session ends.
10. A subsequent session creates a clean new Pi process/session.
11. Stopping the Pontis test container leaves no orphaned Pi process.
12. Tool filesystem behaviour inside the container is understood.
13. The Docker Pontis can be removed and the normal development Pontis
    restarted through Servire without disturbing the rest of the stack.

Servire does not need to manage the Pontis test container. Container
start/stop is manual for this proof. The final M0.1 architecture will
return Pontis to Servire-managed child-process lifecycle inside the
single Lumen application container.

This test resolves the unusual Linux/Docker Pi/ACP dependency using a
real Lumen conversation before the complete Lumen image is built.

------------------------------------------------------------------------

# Part III --- Incremental Dockerisation

## 13. Principle

Dockerisation should not be attempted as one large distribution change.

Each increment should leave us with something independently runnable and
testable.

In particular, we should **not initially introduce HAProxy, a new
MongoDB instance and configurable Ollama at the same time as first
proving that Lumen runs inside Linux Docker**.

------------------------------------------------------------------------

## 14. Stage D1 --- Complete Lumen Application Container

The first complete Dockerisation step should still use the existing
development MongoDB and Ollama. HAProxy and the distribution MongoDB
container are deliberately excluded at this stage.

### 14.1 Stage D1a --- Prove Lumen in One Container

Build one Linux Lumen application container containing all Lumen service
code plus Pi/`pi-acp`.

Initially, `tini` is **not required**. Servire can be the container's
main process while the basic runtime is proved.

For this stage, publish only the Servire port required to reach the
Servire UI. Individual Lumen service ports should not be published
merely for convenience.

``` text
Researcher browser
        |
        | temporary published Servire port
        v
+------------------------------------+
|       Lumen Docker Container       |
|                                    |
| Servire                            |
|   +-- Pontis                       |
|   |     +-- pi-acp -> Pi           |
|   +-- Praebere                     |
|   +-- Moderari                     |
|   +-- Repetere                     |
|   +-- Vestigare                    |
|   +-- Rogare                       |
|   +-- Fiducia                      |
|   +-- Nuntius                      |
+----------------+-------------------+
                 |
        +--------+--------+
        |                 |
        v                 v
 existing MongoDB    existing Ollama
```

The test is intentionally operational rather than synthetic:

1.  Start the Lumen container with Servire.
2.  Connect to the normal Servire UI.
3.  Use Servire to start the Lumen stack.
4.  Verify dependency ordering and health.
5.  Verify Servire captures service stdout/stderr as expected.
6.  Conduct a normal Rogare chat through the running stack.
7.  Exercise Pi/tool operation.
8.  Exercise existing individual service Stop/Start/Restart controls.
9.  Exercise Stack Stop/Start/Restart.
10. Verify the containerised Lumen runtime can use the existing MongoDB
    and existing Ollama.

The purpose is to answer one question:

> **Does the existing Lumen architecture operate normally when its
> application services run as Servire-managed child processes inside one
> Linux container?**

Signal/PID-1 behaviour is deliberately separated from this first proof.

#### D1a networking transition from the Pontis/Pi substitution stage

The earlier Pontis/Pi-only Docker substitution deliberately treats
host-running Vestigare and Rogare as dependencies external to the Pontis
container. Pontis configuration will therefore have been changed
temporarily so those services are reached through Docker-to-host
addresses.

At D1a, Vestigare and Rogare move into the **same Lumen application
container** as Pontis. Pontis configuration must therefore be changed
back to the appropriate internal/loopback service endpoints. The
temporary external Docker-to-host addresses used by the substitution
test must not become part of the final distribution configuration.

D1a must also make **Servire and Pontis container-accessible**. Servire
requires ingress for the operator UI and Pontis requires ingress for
supported external Lumen clients. During D1a, their ports may be
published directly from the Lumen application container for testing.
Vestigare, Rogare and the other internal Lumen services do not require
direct host publication.

When HAProxy is introduced, direct host publication of Servire and
Pontis is removed. HAProxy becomes the sole application ingress and
forwards its separate host/IP + port listeners to the corresponding
container-accessible Servire and Pontis ports.

``` text
D1a test topology

External operator --------> published Servire port
                                      |
                                      v
                            +----------------------+
External Lumen client ---->| Lumen app container  |
       via Pontis port      | Servire              |
                            | Pontis               |
                            |   +--> Vestigare     |
                            |   +--> Rogare        |
                            |   +--> Pi / pi-acp   |
                            | other Lumen services |
                            +----------------------+
```

### 14.2 Service UI Pop-Out During Dockerisation

Some existing Servire service UIs can be opened or "popped out" directly
in a browser. Such behaviour may depend on the browser reaching the
individual service port directly.

Because individual service ports are not intended to be externally
published in the M0.1 distribution, pop-out behaviour may not work
during D1 and may require controlled routing later.

This is **not a D1 blocker**.

Pop-out behaviour should be reviewed toward the end of the distribution
work, once the final HAProxy/network boundary exists. If it can be
supported cleanly through the controlled ingress, it may be restored for
M0.1. Otherwise it should be documented as a known M0.1 limitation/bug.

Individual service ports must not be exposed merely to preserve pop-out
behaviour.

### 14.3 Stage D1b --- Add `tini` and Prove Container Lifecycle

Once D1a is known to work, add `tini` or an equivalent small init as PID
1.

This keeps PID-1/signal handling separate from the basic Linux
Dockerisation proof.

Expected graceful shutdown:

``` text
docker stop <lumen-container>
        |
        | SIGTERM
        v
      tini
        |
        v
     Servire
        |
        v
Servire performs its normal stack shutdown
        |
        v
Lumen child processes terminate
        |
        v
Servire exits
        |
        v
container exits
```

`tini` provides signal forwarding/process-reaping behaviour; it does not
replace Servire's own orderly service shutdown. Servire must respond to
termination by invoking the existing stack shutdown behaviour.

The primary D1b acceptance test is `docker stop` of the Lumen
application container, not stopping Docker Desktop/the Docker engine.

Test:

1.  Start the container.
2.  Start the stack through Servire.
3.  Verify normal chat/tool operation.
4.  Execute `docker stop` for the Lumen container.
5.  Verify Servire receives termination.
6.  Verify Servire shuts down its child services cleanly.
7.  Verify Pontis terminates Pi/`pi-acp`.
8.  Verify Docker does not need to force-kill the normal shutdown.
9.  Restart the container.
10. Start the stack again and verify normal operation.

Abrupt termination (`docker kill`) and stopping Docker Desktop/the
Docker engine are later resilience/acceptance tests rather than
prerequisites for D1b.

------------------------------------------------------------------------

## 15. Stage D2 --- Servire-Configurable Ollama

This work should now be implemented **before the Pontis/Pi Docker
container work**, despite the historical D2 numbering.

Requirements:

1.  remove Pi from External Dependencies and add Ollama;
2.  add Ollama Host/Port and Apply;
3.  Apply stores the proposed endpoint in Servire memory only;
4.  changing/Applying the endpoint invalidates previous validation;
5.  Servire bootstrap has already established MongoDB availability
    before the normal operational UI is entered;
6.  Verify then checks the proposed Ollama endpoint;
7.  validation fails if Ollama is unavailable;
8.  Apply persists the proposed endpoint immediately to MongoDB and
    invalidates any previous Verify state;
9.  Ollama editing/Apply is disabled while the stack is running;
10. remove Praebere's Ollama-connect requirement from process startup;
11. remove Moderari's Ollama-connect requirement from process startup;
12. distribute the verified endpoint to Praebere via `\obt`;
13. Praebere connects/reconciles/discovers models and reports success or
    failure;
14. Praebere failure causes normal Servire startup rollback;
15. distribute the same endpoint to Moderari via `\obt` for inference;
16. test both default `localhost:11434` and a non-default endpoint;
17. verify non-default endpoint persistence across Servire restart.

``` text
Servire   -> authoritative Ollama location + validation/persistence
Praebere  -> model/provider discovery and lifecycle
Moderari  -> model inference
```

------------------------------------------------------------------------

## 16. Stage D3 --- HAProxy Ingress

Once Lumen itself runs correctly in Docker, add the HAProxy container.

HAProxy becomes the **sole externally published Lumen application
ingress**.

M0.1 uses two simple listeners:

``` text
External Client ---> <Lumen-host/IP>:<Servire-port> ---> HAProxy ---> Servire
External Client ---> <Lumen-host/IP>:<Pontis-port>  ---> HAProxy ---> Pontis ---> Vestigare
```

**M0.1 exposes Servire and Pontis through separate HAProxy listeners
identified by host/IP and port. HAProxy forwards each listener to the
corresponding service inside the Lumen application container. Path-based
routing is not required.**

This preserves the existing host/IP + port client model, including an
external Pi acting as a Lumen client through Pontis. It does not change
the separate internal Pi/`pi-acp` child used by Pontis for Rogare tools.

The Lumen container should not publish Servire, Pontis or other service
ports directly to the host.

The Compose distribution creates and owns a **dedicated private Lumen
Docker network**. HAProxy, the Lumen application container and MongoDB
are all attached to this network. Docker service-name resolution is used
for container-to-container addressing; Lumen must not depend on
ephemeral container IP addresses.

Because HAProxy is a separate container, Servire and Pontis must listen
on interfaces reachable from the Lumen Docker network rather than only
container loopback. Other internal Lumen services may continue using
loopback where external-container access is unnecessary. HAProxy's two
required ingress listeners are published on the host; the Lumen
application container does not publish Servire or Pontis directly.

Ollama and Illuminates.One are **not members of the Lumen Docker
network**. Praebere/Moderari reach Ollama through the configured
external endpoint. Licentia reaches Illuminates.One outbound over
HTTPS/TLS on behalf of the authorization exchange.

M0.1 local ingress remains HTTP. HTTPS/TLS termination at the local
HAProxy is deferred beyond M0.1. This is separate from Licentia's
outbound authorization connection to Illuminates.One, which **does use
HTTPS/TLS**. Licentia is not exposed through HAProxy and has no
host-published authorization port.

HAProxy introduction does not automatically require resolution of
existing service-UI pop-out behaviour. That issue should be evaluated
against the final ingress topology toward the end of the M0.1 process
and either supported cleanly through controlled routing or documented as
a known M0.1 limitation.

------------------------------------------------------------------------

## 17. Stage D4 --- Distribution MongoDB

Only after the Lumen container and HAProxy path are working should the
dedicated M0.1 MongoDB container be introduced.

Target:

``` text
                 Lumen-owned private Docker network

HAProxy container --------+
                          |
Lumen container ----------+------> mongodb:27017
                          |
MongoDB container --------+

Remote Compass/script
        |
        v
<Lumen-host>:27018
        |
        v
MongoDB container:27017
```

MongoDB is attached to the same Lumen-owned Docker network as HAProxy
and the Lumen application container. Normal Lumen database traffic
therefore uses Docker DNS/service-name resolution (`mongodb:27017`), not
a fixed container IP. Any host-published MongoDB research interface is a
separate explicit interface and is not routed through HAProxy.

Compose mapping:

``` text
0.0.0.0:27018:27017
```

Requirements:

-   persistent Docker volume;
-   authentication enabled;
-   fixed M0.1 distribution credentials;
-   Lumen service configurations updated consistently;
-   remote Compass connection tested;
-   database persistence across stack restart tested.

------------------------------------------------------------------------

### 17.1 Servire/MongoDB bootstrap acceptance

Distribution MongoDB acceptance must include the failure path, not only
the successful connection path:

1.  start the distribution with MongoDB unavailable;
2.  confirm the Servire web UI is still reachable;
3.  confirm the Servire tab clearly reports that MongoDB is unavailable;
4.  confirm no MongoDB password or credential is displayed;
5.  confirm Verify and Start are unavailable;
6.  confirm all other component tabs remain visible in their existing
    Unavailable state;
7.  restore MongoDB and restart/recover Servire as implemented;
8.  confirm Servire enters its normal operational UI;
9.  confirm the persisted Ollama endpoint is loaded, or the
    `config.yaml` default is used when no persisted value exists.

## 18. Stage D5 --- Illuminates.One Authorization

### 18.1 Purpose and Trust Boundary

M0.1 authorization is intended to make unauthorized copying **detectable
and inconvenient**, not to provide DRM or absolute host tamper
resistance. Legitimate researcher activity, including moving Lumen to a
new machine, must not be made unnecessarily fragile.

Stage D5 introduces **Lumen Licentia** as the dedicated authorization
broker. The durable trust boundary is:

``` text
Servire
   |
   | fresh challenge + signed installation request
   v
Licentia
   |
   | outbound HTTPS/TLS
   v
Illuminates.One
   |
   | signed, challenge-bound authorization proof
   v
Licentia
   |
   | transports proof unchanged
   v
Servire
   |
   | independently verifies proof
   v
authorization gate
```

The roles are deliberately separated:

- **Illuminates.One** is the external authorization authority.
- **Licentia** owns the external authorization transport/protocol
  exchange and operational renewal brokerage.
- **Servire** owns the installation private key, generates request
  freshness, independently verifies Illuminates.One authorization proofs,
  and remains the runtime gate for protected Stack operation.
- **Nuntius / `\obt` is not part of the authorization path.**
- **HAProxy does not expose or route Licentia.**

Licentia must never become a local authority whose plain assertion of
`AUTHORIZED` is sufficient for Servire. A captured or forged
Licentia-to-Servire status response must not be capable of authorizing
the Stack.

The Lumen container starts Servire. Servire starts/checks Licentia as an
authorization prerequisite, but successful authorization does **not**
automatically launch the protected Stack. It enables the existing
Servire Verify/Start workflow.

``` text
Docker starts Lumen container
          |
          v
        tini
          |
          v
       Servire
          |
          +-- load/create installation identity
          |
          +-- start/check Licentia
          |
          +-- generate fresh authorization challenge
          |
          v
       Licentia
          |
          v
    Illuminates.One
          |
          v
 signed authorization proof
          |
          v
       Licentia
          |
          v
       Servire verifies proof
          |
       +--+--+
       |     |
     failed valid
       |     |
       v     v
 Start controls   Verify and Start controls
 disabled         become available
```

If authorization cannot be established, Servire remains available in a
restricted startup state and presents an authorization failure/retry
surface analogous to the MongoDB bootstrap-failure experience.

### 18.2 D5 Initial Vertical Slice

The first D5 implementation deliberately proves the complete service
path before the full cryptographic protocol is enabled.

The initial Illuminates.One endpoint accepts a JSON authorization POST
from Licentia and returns a deterministic successful JSON response that
includes the challenge supplied by Servire.

Conceptually:

``` json
{
  "authorized": true,
  "challenge": "<servire-challenge>",
  "message": "OK"
}
```

For this first vertical slice, the response is **not yet a secure
authorization proof**. Echoing the challenge proves request/response
correlation and establishes the permanent interface shape, but it does
not by itself provide signature authenticity or replay resistance.

The initial D5 slice therefore proves:

``` text
Servire challenge
      -> Licentia
      -> Illuminates.One
      -> Licentia
      -> Servire challenge match
```

The full signed protocol described below is then layered onto this
working path without changing the fundamental service boundary.

### 18.3 Installation Identity Provisioning and Persistence

On first start, if no installation identity exists, **Servire** generates:

- a random installation identifier;
- an asymmetric private/public key pair.

The identity is stored in a **dedicated persistent Docker volume**, not
in the disposable container filesystem and not in MongoDB:

``` text
Docker host
|
+-- lumen-identity volume
|     +-- installation_id
|     +-- private_key
|     +-- public_key
|
+-- Lumen application container
|     +-- Servire mounts/uses identity volume
|     +-- Licentia does not own the installation private key
|
+-- MongoDB volume
      +-- application/research data
```

A normal `docker compose down` followed by `docker compose up` retains
the same installation identity. Deliberately deleting the identity
volume creates a new installation identity on the next start. The
identity is **not derived from a Docker container ID**.

The installation private key is never transmitted to Licentia or
Illuminates.One. Keeping the private key at Servire means that replacing,
sniffing or modifying Licentia does not provide the capability to sign
a new installation authorization request.

The private key remaining readable to a user with full Docker-host/root
control is an accepted M0.1 boundary; stronger protected or
hardware-backed key storage may be added later.

### 18.4 User Registration Key

Illuminates.One creates and persists the **user registration key** before
the researcher downloads the M0.1 distribution.

The registration lifecycle remains:

``` text
Researcher/distribution registration
              |
              v
Illuminates.One generates and persists
a unique user registration key
              |
              v
            ISSUED
              |
              | successful distribution download
              v
          REGISTERED
              |
              | first valid authorization
              v
            ACTIVE
              |
              +--> bound to installation_id
              +--> bound to installation_public_key
              +--> cannot bootstrap another installation
```

The states mean:

- **ISSUED** --- the key exists and is associated with the appropriate
  researcher/distribution entitlement.
- **REGISTERED** --- distribution download has been recorded, but the
  key is not yet bound to an installation.
- **ACTIVE** --- Illuminates.One has validated the first signed
  installation request and bound the entitlement to the
  `installation_id` and installation public key.

Once ACTIVE, the registration key has completed its bootstrap purpose.
Routine authorization and renewal use the installation identity and
Servire-signed requests rather than the registration key.

### 18.5 HTTPS, Signing and End-to-End Proof

The external Licentia ↔ Illuminates.One transport uses **HTTPS/TLS**.
Application-level signatures provide the end-to-end authorization trust
that reaches Servire.

There are two distinct asymmetric identities.

#### Illuminates.One signing identity

Illuminates.One retains its authorization-signing private key. The
corresponding public verification key is provisioned into the Lumen
distribution and trusted by Servire.

``` text
Illuminates.One PRIVATE key
    -> retained only by Illuminates.One
    -> signs authorization proofs

Illuminates.One PUBLIC key
    -> provisioned into Lumen
    -> used by Servire
    -> verifies authorization proofs
```

Licentia does not possess the Illuminates.One private key and therefore
cannot manufacture an authorization proof Servire will accept.

#### Lumen installation signing identity

Servire owns the installation private key:

``` text
Servire installation PRIVATE key
    -> retained in lumen-identity volume
    -> never transmitted
    -> signs authorization requests/challenges

installation PUBLIC key
    -> supplied during bootstrap
    -> registered by Illuminates.One
    -> used by Illuminates.One to verify later requests
```

Licentia transports the signed request but does not sign it on behalf of
Servire.

The trust directions are therefore:

``` text
Servire                                    Illuminates.One

installation PRIVATE key
        |
        +-- signs request/challenge -----> verifies using registered
                                           installation PUBLIC key


Illuminates.One PRIVATE key
        |
        +-- signs authorization proof ---> Servire verifies using
                                           provisioned Illuminates.One
                                           PUBLIC key

             Licentia transports both directions
             but owns neither private signing key
```

Signed Illuminates.One responses identify the signing key with a stable
`key_id` so future key rotation can be supported.

### 18.6 Fresh Challenge and Request Metadata

Servire generates a cryptographically random fresh challenge for each
authorization request. The signed request carries the semantic
equivalent of:

``` text
protocol_version
request_type                 initial_registration | lease_renewal
request_id
challenge
requested_at

distribution_id
Lumen release/version
Servire version

installation_id
installation_public_key      initial registration where required
user_key                     initial registration only
current_lease_id             renewal where available

runtime_id
runtime_auth_sequence
machine_fingerprint
```

Servire signs the request with the installation private key before
passing it to Licentia.

Licentia may add transport-level metadata only where explicitly defined
by the protocol; it must not alter fields covered by the Servire
signature.

`runtime_id` is randomly generated when a Servire runtime starts.
`runtime_auth_sequence` is an in-memory counter reset on each Servire
start and incremented for every authorization request.

The machine fingerprint remains a stable **host-machine observation**,
not a Docker-container identity or an automatic authorization decision.
Illuminates.One may also record the source public IP observed on the
HTTPS connection.

No research content is transmitted: no prompts, responses, traces,
experiment names/results, MongoDB contents, model catalogues or
tool-call content.

### 18.7 Authorization Proof and Servire Verification

A successful signed Illuminates.One authorization proof contains the
semantic equivalent of:

``` text
protocol_version
response_type
key_id
request_id
request_challenge

installation_id
distribution_id
authorization = granted

lease_id
issued_at
lease_expires_at
grace_expires_at
next_check_after
reason_code / message         where applicable

signature
```

Licentia returns this proof to Servire without converting it into a
plain trusted `AUTHORIZED` assertion.

Servire must independently validate at least:

- the response identifies a trusted `key_id`;
- the Illuminates.One signature verifies using the corresponding
  provisioned public key;
- `installation_id` and `distribution_id` match this installation;
- `request_id` matches the outstanding request;
- `request_challenge` exactly matches the fresh challenge Servire
  generated for that request;
- timestamps and lease/grace values are valid and sufficiently fresh;
- the authorization state is recognised by the protocol.

Only after those checks succeed may Servire treat the installation as
authorized.

A previously captured proof cannot satisfy a later request because the
new Servire challenge differs. A modified proof fails signature
verification. A fabricated Licentia response lacks a valid
Illuminates.One signature.

### 18.8 Lease, Renewal and Licentia State

For M0.1 the intended policy remains:

- **24-hour authorization lease**;
- normal renewal approximately every **6 hours**, directed by signed
  `next_check_after`;
- after a failed/no-valid-response renewal, retry **hourly**;
- **24-hour grace period beginning at the end of the last valid lease**.

Licentia may own the operational mechanics of scheduling/brokering
renewal attempts and may expose useful status to Servire. However,
Licentia's local state is **not itself cryptographic authority**.

The authoritative basis for Servire's authorization decision remains
the most recent Illuminates.One-signed proof that Servire has
successfully verified.

Conceptually:

``` text
Licentia
   -> knows when renewal should be attempted
   -> performs external HTTPS exchange
   -> reports transport/protocol status
   -> returns signed proof

Servire
   -> verifies signed proof
   -> retains verified lease/grace timestamps
   -> decides whether protected operation is permitted
```

This preserves useful separation without terminating the trust chain at
Licentia.

### 18.9 Failure, Grace and Revocation Behaviour

A communication failure is not the same as a positive denial.

``` text
No response / timeout / Illuminates.One unavailable
    -> retain current verified valid lease
    -> retry according to policy
    -> continue through defined post-lease grace

Malformed / unverifiable / bad-signature proof
    -> never treat as authorization or revocation
    -> retain current verified lease/grace where applicable
    -> record security/validation failure
    -> retry according to policy

Valid Illuminates.One-signed DENIED / REVOKED proof
    -> Servire verifies signature/challenge/identity
    -> explicit authorization withdrawal
    -> no grace period granted by that response
    -> prevent new protected work
    -> controlled shutdown as appropriate
```

If authorization fails during initial Servire startup and no valid
lease/grace exists, Servire remains available but the protected Stack
cannot be started. The Servire UI presents an authorization failure
surface with a **Retry Authorization** action.

A temporary Illuminates.One or Internet outage during an already
authorized runtime must not immediately terminate a research session.

### 18.10 Moving Lumen to Another Machine

A legitimate move must not create avoidable downtime or require
automatic rejection merely because host fingerprint or source IP
changed.

If the `lumen-identity` volume is moved with the installation, the same
installation ID and key pair remain authoritative. Illuminates.One
records changes in host fingerprint, runtime ID and source IP as
observations, not automatic denial conditions.

If the identity volume is lost, a new key pair represents a replacement
installation and may require administrative reset/re-authorization.

### 18.11 Clone/Anomaly Detection --- Alert, Do Not Automatically Punish

M0.1 records enough metadata to identify activity consistent with a
copied installation while avoiding brittle automatic enforcement.

Illuminates.One may maintain authorization-request counts and a
configurable administrative threshold:

> **More than X authorization requests within the configured observation
> period → ALERT.**

Exceeding the threshold does not automatically deny authorization,
revoke the lease or stop Lumen.

Supporting evidence may include installation ID, runtime IDs,
authorization sequence counters, host-machine fingerprints, source
public IPs, timestamps, overlapping runtimes, lease IDs and
Lumen/Servire versions.

Suspected cloning remains an **alert condition, not an automatic
authorization failure**. Enforcement following an alert requires human
review.

### 18.12 First-Registration Public-Key Bootstrap

Illuminates.One does not need the installation public key before the
first authorization request.

On first Servire startup:

1. Servire obtains or creates its durable `installation_id`.
2. Servire generates the installation asymmetric key pair in the
   dedicated identity volume.
3. The installation private key remains local and is never transmitted.
4. Servire generates a fresh challenge.
5. Servire constructs the initial registration request containing the
   user registration key, `installation_id`, installation public key,
   challenge and required runtime metadata.
6. Servire signs the request using the installation private key.
7. Servire passes the signed request to Licentia.
8. Licentia transports the request to Illuminates.One over HTTPS/TLS.
9. Illuminates.One verifies proof of possession using the supplied public
   key and separately validates the user registration key.
10. Illuminates.One binds the entitlement to the installation identity
    and public key.
11. Illuminates.One signs a response containing the same request
    challenge.
12. Licentia returns the signed proof unchanged to Servire.
13. Servire verifies the Illuminates.One signature, challenge binding,
    installation/distribution identity and validity before accepting
    authorization.

After bootstrap, the registration key is no longer required for routine
authorization. Subsequent requests are signed by Servire and verified
against the already registered installation public key.

### 18.13 Extensibility Requirement

The M0.1 authorization model must allow later releases to strengthen
rather than replace it. Potential extensions include stronger machine
identity/attestation, hardware-backed Servire key storage, richer
entitlement policy, improved anomaly detection and more automated
administrative workflows.

The durable foundation is:

- persistent Servire-owned installation identity and asymmetric key pair;
- one-time user-key bootstrap registration;
- fresh Servire-generated challenges;
- Licentia as the dedicated authorization broker;
- signed end-to-end Servire ↔ Illuminates.One (via Licentia) authorization messages,
  transported by Licentia;
- Servire verification of Illuminates.One proofs;
- renewable leases with defined outage/grace behaviour;
- runtime, host and network observations;
- alert-first clone/anomaly handling;
- human-controlled enforcement decisions.

------------------------------------------------------------------------

## 19. Internal Protected-Service Authorization Boundary

For the current single Lumen application-container M0.1 runtime, Stage
D5 does **not** introduce a second authorization protocol into every
protected service merely to prove the external authorization path.

Servire remains the runtime gate:

> **Protected Lumen services are launched only after Servire has
> independently verified a fresh Illuminates.One authorization proof.**

This avoids prematurely adding duplicate authorization logic,
service-level lease state and pseudo-start/stop semantics while D5 is
being established.

However, the wider Phase 11 security plan retains a later hardening
stage for **Servire-authorised, stack-bound protected-service startup**.
That later stage may add short-lived startup authorization bound to the
installation, deployment, service and current startup event where
required by the final M0.1 security boundary.

Therefore:

- D5 establishes and proves the external Servire → Licentia →
  Illuminates.One → Licentia → Servire trust path;
- Licentia does not authorize protected services directly;
- Nuntius / `\obt` does not carry authorization;
- Servire remains the protected Stack lifecycle gate;
- later stack-bound startup proof is treated as a separate hardening
  stage rather than being conflated with D5.

------------------------------------------------------------------------

# Part IV --- Proposed Implementation Order

## 20. Recommended Sequence

### A. Servire-configurable Ollama

Implement the agreed Apply -\> Verify -\> persist lifecycle; move
Praebere and Moderari Ollama connectivity from process startup to
receipt of Servire `\obt`; retain Servire rollback if Praebere cannot
establish the provider.

### B. Pontis/Pi initial Lumen container

Create the **base M0.1 Lumen application image**, install Pontis,
Pi/`pi-acp`, substitute it for native Pontis in the existing development
stack, and prove a real Rogare chat/tool operation. Retain this
image/Dockerfile for expansion.

### C. Complete Lumen application container

Add Servire and the remaining Lumen services to the same image;
initially use existing MongoDB and Ollama; publish Servire temporarily;
prove normal stack/service lifecycle and complete Lumen operation.

### D. Add `tini`

After the application container is known to work, add `tini` and prove
graceful `docker stop`, Servire child shutdown, Pi termination and clean
restart.

### E. HAProxy

Add the separate HAProxy container, route the controlled application
ingress to Servire/Pontis and remove direct Lumen service publication.

### F. Distribution MongoDB

Add the persistent authenticated MongoDB container, fixed M0.1
credentials and `0.0.0.0:27018` research access.

### G. Installation Identity Provisioning

Generate the installation cryptographic identity/key material in
Servire on first start and retain it in the dedicated persistent
`lumen-identity` Docker volume. Establish the installation
identifier/public material needed for later authorization. The identity
survives normal container recreation and is independent of Docker
container IDs. Licentia does not own or receive the installation private
key.

**Installation identity generation is separate from Illuminates.One
authorization.**

### H. Licentia and Illuminates.One Authorization

Introduce Licentia as the dedicated private authorization broker.
Servire generates fresh challenges and signs installation authorization
requests; Licentia transports those requests to Illuminates.One over
HTTPS/TLS. Illuminates.One returns signed, challenge-bound authorization
proofs through Licentia, and Servire independently verifies them using
the provisioned Illuminates.One public key.

Begin with the D5 challenge-echo vertical slice, then add the full signed
bootstrap/lease protocol using the already-provisioned installation
identity and one-time researcher/user registration key. Retain the
agreed 24-hour lease, six-hour normal check, hourly failure retry,
24-hour post-lease grace and alert-first clone/anomaly observation.

Authorization does not use Nuntius or `\obt`, and Licentia is not
exposed through HAProxy.

### I. Final Distribution Validation

Perform fresh-machine, persistence, shutdown/restart, authorization,
Ollama, MongoDB, Pi/tool, HAProxy and remote research-access acceptance
testing. Review service UI pop-out behaviour at this stage and either
support it cleanly or document it as an M0.1 limitation.

------------------------------------------------------------------------

# 21. Why This Sequence

Servire-configurable Ollama comes first because it is already a required
runtime correction for both Praebere and Moderari and can be proved
against the existing development stack.

The Pontis/Pi Docker work then creates the first real Lumen application
image rather than a disposable spike. That same image is expanded into
the complete application container.

`tini` is deliberately added only after the application container works,
so PID-1/signal handling is tested independently of basic Dockerisation.

HAProxy and the distribution MongoDB follow only after Lumen itself is
known to run correctly in the container.

Installation identity provisioning is separate from authorization: the
installation first obtains its cryptographic identity; authorization
later uses that identity.

------------------------------------------------------------------------

# 22. Decisions Now Considered Agreed

For review, the current agreed design is:

-   **One Lumen application container** containing the Lumen service
    processes plus Pi/`pi-acp`.
-   **Servire remains the real process supervisor** and retains genuine
    Start/Stop/Restart semantics.
-   **`tini` or equivalent** handles PID 1/signal forwarding.
-   **The Compose distribution creates and owns a dedicated private
    Lumen Docker network.**
-   **HAProxy, the Lumen application container and MongoDB are attached
    to that network.** Internal container-to-container addressing uses
    Docker service-name resolution rather than fixed container IP
    addresses.
-   **Ollama and Illuminates.One remain external to the Lumen Docker
    network.**
-   **MongoDB remains a separate container.**
-   MongoDB is exposed as **`0.0.0.0:27018:27017`** for external
    research access.
-   MongoDB authentication is enabled with **fixed M0.1 credentials ---
    do not change**.
-   **HAProxy remains a separate container** and becomes the sole
    external Lumen application ingress.
-   HAProxy exposes **separate host/IP + port listeners for Servire and
    Pontis** and forwards each listener to the corresponding process;
    path-based routing is not required.
-   The Lumen application container does not directly publish its
    service ports.
-   **Praebere and Moderari may make outbound connections to external
    Ollama.**
-   **Servire may make outbound HTTPS connections to Illuminates.One.**
-   Ollama is considered **external to Lumen**, regardless of whether it
    physically runs natively, in Docker or remotely.
-   **Servire owns the authoritative Ollama endpoint** for M0.1. MongoDB
    is a mandatory Servire bootstrap dependency. Apply changes the
    in-memory endpoint and persists it immediately to MongoDB; Apply
    invalidates the previous Verify state. Verify performs lightweight
    Ollama reachability and the remaining checks before enabling Start.
-   Praebere and Moderari receive the authoritative Ollama endpoint
    through the existing **Nuntius `\obt` control plane**.
-   **Praebere owns model/provider discovery and lifecycle; Moderari
    owns model inference.** Sharing the same endpoint does not merge
    these responsibilities.
-   **Praebere startup must no longer depend on Ollama being
    reachable.**
-   **Moderari must be able to reach operational state before the
    Servire-owned Ollama endpoint is available/reachable.**
-   In future, **Servire becomes authoritative for all external
    connections and credentials**, distributing required information
    through `\obt`.
-   **Existing Pontis/Pi provider behaviour remains unchanged for M0.1;
    Dockerisation does not introduce a provider redesign.**
-   Existing Rogare-driven **tool-free operation** remains supported by
    Pontis without requiring Pi; no new external Pontis tool selector is
    introduced for M0.1.
-   Pi/`pi-acp` is a **child-process dependency**, not a separate
    network service.
-   **Pi is not a Servire External Dependency; Ollama is.**
-   Applying a changed Ollama endpoint invalidates previous validation.
-   **Installation identity/key generation is separate from
    Illuminates.One authorization and persists in a dedicated Docker
    volume.**
-   **No internal per-service authorization tokens are required for
    M0.1.**
-   Illuminates.One authorization **enables Servire's Verify/Start
    controls; it does not automatically start the stack or services.**
-   Authorization uses **HTTPS/TLS plus signed requests/responses**;
    separate application-level payload encryption is not required for
    M0.1.
-   Initial registration consumes a **one-time researcher/user
    authorization key** and binds it to the persistent installation
    ID/public key.
-   Runtime authorization uses a **24-hour lease**, normal renewal at
    approximately six hours, hourly retry after failure, and a **24-hour
    grace period after lease expiry**.
-   Host fingerprint, observed source IP, runtime ID and in-memory
    authorization sequence are **evidence/telemetry**, not automatic
    machine-locking controls.
-   **More than X authorization requests within the configured
    observation period raises an ALERT**, not automatic denial.
    Suspected cloning requires human review before enforcement.
-   Legitimate movement of the persistent installation identity to
    another machine is allowed; changed host/IP metadata is recorded
    rather than automatically rejected.
-   The M0.1 authorization mechanism must be **extensible rather than
    disposable**, allowing later security/attestation enhancements
    without replacing the basic protocol.
-   HTTPS/TLS for local M0.1 HAProxy ingress remains deferred.
-   Existing service-UI **pop-out behaviour is deferred for later
    review** and may be documented as a known M0.1 limitation rather
    than exposing individual service ports.

------------------------------------------------------------------------

# 23. Items Still to Design During Implementation

The following should remain deliberately unfrozen until the relevant
code is inspected or the implementation stage is reached:

-   exact Servire → Praebere and Servire → Moderari `\obt`
    message/schema and acknowledgement semantics for Ollama
    configuration;
-   future Pontis tool-provider discovery/configuration architecture
    beyond the minimal M0.1 provider boundary;
-   how Pi-specific executable/runtime information is represented;
-   removal/separation of any static Pi model assumption from Pontis's
    authoritative per-session model selection;
-   exact Linux directory/virtual-environment layout inside the Lumen
    image;
-   final name and structure of the distribution Servire configuration
    file;
-   exact HAProxy host port numbers for the separate Servire and Pontis
    listeners;
-   exact asymmetric algorithm/key encoding and host-fingerprint inputs;
-   exact wire schema/signature canonicalization and Illuminates.One API
    endpoint;
-   configurable authorization ALERT threshold X and observation period;
-   fixed M0.1 MongoDB credential values.

These are implementation details, not reasons to reopen the overall
architecture.

------------------------------------------------------------------------

## 24. Resulting M0.1 Boundary

The final conceptual boundary is:

``` text
DOCKER NETWORK BOUNDARY

        Lumen-owned private Docker network

        +-------------------------------+
        | HAProxy                       |
        | Lumen application container   |
        | MongoDB                       |
        +-------------------------------+

Ollama and Illuminates.One remain external to this network.


INBOUND APPLICATION TRAFFIC

External Client
  |
  | Lumen host/IP + listener port
  v
HAProxy
  |
  +----> Servire
  |
  +----> Pontis ----> Vestigare


OLLAMA CONFIGURATION

Apply -------------------> proposed endpoint in Servire memory
Servire startup ---------> MongoDB bootstrap connection
Apply ---------------------> persist Ollama endpoint to MongoDB
Verify --------------------> Ollama reachability + remaining checks

RUNTIME OLLAMA TRAFFIC

Praebere ----------------> configured Ollama
                            [discovery / lifecycle]

Moderari ----------------> configured Ollama
                            [inference]

RUNTIME AUTH TRAFFIC

Servire -----------------> Illuminates.One


RESEARCH DATA

Lumen -------------------> MongoDB :27017
Remote research tooling --> Host :27018 --> MongoDB :27017


INSTALLATION IDENTITY

Generate installation identity
        |
        +---- private key retained locally
        +---- identity/public material used later for authorization


PROCESS AUTHORITY

Docker
  |
  v
tini
  |
  v
Servire
  |
  | successful Illuminates.One authorization
  v
Verify / Start controls enabled
  |
  | researcher explicitly starts stack/services
  v
Lumen child processes


TOOL EXECUTION

Pontis
  |
  +---- tools disabled ----> no provider
  |
  +---- tools enabled
            |
            +---- Pi / pi-acp     [M0.1]
            |
            +---- future provider [future]
```

This provides a practical M0.1 distribution architecture without turning
Dockerisation into a redesign of Lumen itself.
