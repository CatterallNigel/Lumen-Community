# Lumen M0.1 --- Illuminates.One Research Registration, Authorization and Evidence Model

> **INTERNAL SECURITY DESIGN --- PRIVATE**
>
> **Do not publish to Lumen-Community.**
>
> This document contains implementation-level details of the Lumen M0.1
> registration, authorization, trust, persistence, recovery and
> operational evidence design.

**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)
**Date:** 2026-09-19\
**Scope:** Illuminates.One authorization service, Servire, Licentia,
researcher registration and MongoDB persistence

------------------------------------------------------------------------


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## 1. Purpose

M0.1 is the first external research distribution of Lumen. Although the
initial release is expected to involve only a very small number of
researchers, the authorization system should establish the structural
foundation needed for a wider research release.

The design therefore separates:

-   the researcher who is entitled to receive Lumen;
-   the one-time registration key issued to that researcher;
-   the cryptographically registered Lumen installation;
-   authorization leases issued to that installation; and
-   append-only operational evidence describing authorization activity.

The M0.1 policy is deliberately **observation-first rather than
punitive**. Unexpected behaviour is recorded and flagged for human
assessment. It does not automatically disable a research installation
unless Illuminates.One has made an explicit administrative decision to
lock it.

------------------------------------------------------------------------

## 2. Core Principles

### 2.1 Trust ownership

The authorization trust chain is:

``` text
Illuminates.One
      │
      │ signed authorization decision / lease
      ▼
   Licentia
      │
      │ opaque transport
      ▼
    Servire
      │
      │ independently verifies proof
      ▼
 protected Lumen Stack
```

Responsibilities are deliberately separated:

-   **Illuminates.One owns authorization policy and authorization
    decisions.**
-   **Servire owns installation identity and verification of trust.**
-   **Licentia owns communication only.**
-   Licentia does not decide whether Lumen is authorized.
-   Licentia cannot manufacture a valid authorization proof.
-   Other Lumen services do not communicate directly with
    Illuminates.One.

### 2.2 Cryptographic ownership

``` text
Lumen installation                         Illuminates.One
──────────────────                         ───────────────
Servire installation private key           Illuminates private key
        │                                          │
        ├─ signs authorization request             ├─ signs authorization response
        │                                          │
Servire installation public key            Illuminates public key
        │                                          │
        └──── supplied at registration ───────────►│
                                                   │
        ◄──── trusted with distribution ───────────┘
```

Servire verifies Illuminates.One responses using the trusted
Illuminates.One public key.

The installation private key never leaves the installation. The
Illuminates.One private signing key never enters the Lumen distribution.

### 2.3 Local storage separation

The logical Servire layout is:

``` text
Servire/
├── trust/
│   └── illuminates_one_authorization_public_key.pem
│
├── data/
│   └── identity/
│       ├── installation.json
│       ├── installation_private_key.pem
│       └── installation_public_key.pem
│
└── secrets/
    └── registration_key
```

The meanings are deliberately distinct:

-   `trust/` contains public material used to establish trust in
    Illuminates.One.
-   `data/identity/` contains the persistent identity of this Lumen
    installation.
-   `secrets/` contains provisioning secrets, including the one-time
    registration key.

The registration key should not be treated as a trust anchor.

After successful initial registration, Servire no longer needs to
transmit the registration key. Its local retention policy can therefore
remove it after registration has been durably recorded.

------------------------------------------------------------------------

## 3. Researcher Registration

The eventual research release should require a researcher to register
before receiving Lumen.

Only minimal information should initially be collected:

-   name;
-   email address;
-   organisation, where applicable.

The email address is operationally required for distribution links,
registration information and necessary communication with the
researcher.

The system should not collect additional personal information without an
identified requirement.

Researcher information is administrative data and is deliberately
separated from technical authorization telemetry.

### 3.1 Researcher lifecycle

``` text
Researcher registers with Illuminates.One
              │
              ▼
minimal researcher record created
              │
              ▼
unique registration key generated
              │
              ▼
key associated with researcher
              │
              ▼
researcher receives distribution / instructions
              │
              ▼
first Servire startup uses registration key
              │
              ▼
installation becomes cryptographically registered
              │
              ▼
subsequent authorization uses installation identity
```

A future public registration process will require an appropriate privacy
policy, registration notice, retention policy and related controls. M0.1
should nevertheless establish the data-minimised structure now.

------------------------------------------------------------------------

## 4. Registration Key

### 4.1 Purpose

The `registration_key` is a **one-time licence/bootstrap credential**
issued by Illuminates.One.

It establishes that the first registration request is associated with
someone who should have received the research distribution.

It is not the continuing identity of the Lumen installation.

Once registration succeeds, the installation's Ed25519 key pair becomes
the continuing cryptographic identity.

### 4.2 Registration key storage

Illuminates.One stores the actual registration key in
`registration_keys`.

For M0.1 there is no requirement to hash the key. The administrative
system needs to be able to see which keys were issued, which remain
unused, which were consumed, and which appeared without having been
issued.

A unique MongoDB index on `registration_key` prevents duplicate
persisted keys.

The registration key must not be copied into general authorization event
logs.

### 4.3 Structural validation

The registration-key format is:

``` text
LUMEN-<RELEASE>-XXXX-XXXX-XXXX-XXXX
```

For M0.1, for example:

``` text
LUMEN-M01-7K4P-9W2X-H8RT-Q3NM
```

`LUMEN` is the fixed product identifier. The `<RELEASE>` component identifies
the Lumen release for which the registration key was issued. For M0.1 this is
`M01`; future releases use their corresponding release identifier.

The release component is therefore meaningful protocol data rather than a
decorative prefix. Illuminates.One checks whether the supplied release
identifier exists in its release registry.

The four variable blocks each contain exactly four characters and use only
the following unambiguous uppercase alphanumeric character set:

``` text
ABCDEFGHJKLMNPQRSTUVWXYZ23456789
```

The ambiguous characters `I`, `O`, `1`, and `0` are deliberately excluded to
reduce transcription errors.

Each four-character block must contain:

-   at least one letter; and
-   at least one digit.

A registration key is structurally valid only when it:

-   is non-null and non-blank;
-   begins with the fixed `LUMEN-` product identifier;
-   contains a syntactically valid release identifier;
-   has exactly four four-character variable blocks separated by hyphens;
-   contains only characters from the permitted character set in each
    variable block; and
-   contains at least one letter and one digit in every variable block.

Structural validity and recognition are separate decisions.

For M0.1:

-   a malformed key is rejected;
-   a structurally valid key referring to a release that Illuminates.One has
    never recorded is authorized, persisted and flagged with the observation
    `UNKNOWN_RELEASE`;
-   a structurally valid key for a known release that is not present in
    `registration_keys` is authorized, persisted with registration-key status
    `UNKNOWN`, and flagged with `UNKNOWN_REGISTRATION_KEY`;
-   if both conditions apply, both observations are retained; and
-   a known release with a known registration key proceeds normally.

`UNKNOWN_RELEASE` and `UNKNOWN_REGISTRATION_KEY` are observations, not
automatic denial decisions during M0.1.

This allows Illuminates.One to distinguish malformed input from a plausible
Lumen registration credential whose release, key, or both are unexpected.

### 4.4 Known and unknown keys

M0.1 uses the following policy:

  -----------------------------------------------------------------------
  Registration-key condition          Action
  ----------------------------------- -----------------------------------
  Missing, null or blank              Reject initial registration

  Structurally malformed              Reject initial registration

  Structurally valid and already      Register/authorize normally
  known                               

  Structurally valid but not          Register, authorize, persist as
  previously known                    `UNKNOWN`, and flag for review
  -----------------------------------------------------------------------

An unknown but structurally valid key is therefore **not an automatic
denial in M0.1**.

When such a key first appears, Illuminates.One creates a
`registration_keys` record for it rather than creating a separate
unknown-key collection.

If subsequent human review establishes that it is legitimate, its status
can be changed:

``` text
UNKNOWN → KNOWN
```

The historical fact that it was first encountered as unknown should
remain available.

------------------------------------------------------------------------

## 5. Initial Registration

The first successful installation authorization is different from
subsequent authorization.

Servire sends:

``` text
request_type = initial_registration

registration_key
installation_id
installation_public_key
request_id
challenge
requested_at
distribution_id
lumen_version
servire_version
runtime_id
runtime_auth_sequence
machine_fingerprint
run_counter where applicable
signature_algorithm
signature
```

The request is signed by the installation private key.

Illuminates.One:

1.  validates the registration-key structure;
2.  determines whether the key is known or unknown;
3.  verifies possession of the supplied installation public key by
    verifying the signed request;
4.  creates or validates the installation registration;
5.  binds the registration record to the installation identity;
6.  records the authorization event;
7.  issues a signed 24-hour authorization lease.

For a structurally valid unknown registration key, the same process
occurs but the key is recorded as `UNKNOWN` and flagged for review.

A registration key must never silently replace the trusted public key of
an already registered installation.

------------------------------------------------------------------------

## 6. Subsequent Startup and Lease Renewal

After successful registration, Servire must not continue to send the
registration key as its authority.

A subsequent authorization request uses:

``` text
request_type = lease_renewal

installation_id
current_lease_id where available
request_id
challenge
requested_at
distribution_id
lumen_version
servire_version
runtime_id
runtime_auth_sequence
machine_fingerprint
run_counter where applicable
signature_algorithm
signature
```

It does **not** supply:

``` text
registration_key
installation_public_key
```

Illuminates.One retrieves the registered public key associated with
`installation_id` and uses that stored key to verify the signed request.

This proves that the continuing authority is the registered installation
identity rather than continued possession of the original bootstrap
credential.

------------------------------------------------------------------------

## 7. Authorization Lease

The M0.1 authorization lease duration is:

**24 hours**

A successful response conceptually contains:

``` json
{
  "protocol_version": "1",
  "response_type": "authorization",
  "request_id": "<original-request-id>",
  "installation_id": "<installation-id>",
  "challenge": "<original-challenge>",
  "authorized": true,
  "decision": "AUTHORIZED",
  "lease_id": "<uuid>",
  "issued_at": "<UTC>",
  "expires_at": "<UTC + 24 hours>",
  "distribution_id": "lumen-research-m0.1",
  "signature_algorithm": "Ed25519",
  "signature": "<Illuminates.One signature>"
}
```

The Illuminates.One signature covers the canonical representation of the
response fields other than `signature`.

Servire verifies:

-   Illuminates.One Ed25519 signature;
-   request ID;
-   installation ID;
-   challenge;
-   distribution ID;
-   authorization decision;
-   lease timestamps and validity.

All authorization timestamps are UTC.

Protocol timestamps use ISO-8601 UTC with `Z`. Internally, MongoDB
should use native UTC/BSON dates where appropriate.

------------------------------------------------------------------------

## 8. Authorization State and Recovery

Servire owns the authorization state machine.

Illuminates.One persists the authoritative authorization decision on the
`lumen_installations` document:

``` text
authorization_status = AUTHORIZED | LOCKED
```

This is the single authoritative answer to whether a registered installation
may receive a new authorization lease.

Servire separately owns its local runtime authorization state machine:

``` text
UNAUTHORISED
AUTHORIZING
AUTHORISED
GRACE
EXPIRED
LOCKED
```

`GRACE` and `EXPIRED` are therefore Servire runtime states, not
Illuminates.One installation states.

### 8.1 Connection failure

If Illuminates.One cannot be reached, this is not the same as an
explicit denial.

An existing valid lease remains effective. Once it expires, Servire
enters its configured grace behaviour. If grace subsequently expires,
protected Stack operation can be withheld.

Servire, Nuntius and Licentia remain operational so authorization
recovery remains possible.

A suitable user-facing message after authorization expires because
Illuminates.One cannot be contacted is:

> **Authorization service unavailable. Please check your network
> connection. Lumen will continue trying to renew its authorization.**

### 8.2 Renewal after grace expiry

`EXPIRED` is not a terminal state.

Servire continues periodically attempting authorization after the grace
period has ended.

``` text
AUTHORISED
     │
 renewal unavailable
     ▼
   GRACE
     │
 grace expires
     ▼
  EXPIRED
     │
     │ continuing renewal attempts
     ▼
valid signed lease received
     │
     ▼
AUTHORISED
     │
normal operation restored
```

A researcher should not need to reinstall or re-register merely because
connectivity to Illuminates.One was unavailable for longer than the
grace period.

### 8.3 Explicit Illuminates.One lock

An explicit administrative lock is distinct from connection failure or
anomaly detection.

The authoritative decision lives in:

``` text
lumen_installations.authorization_status
```

with the M0.1 values:

``` text
AUTHORIZED
LOCKED
```

When a valid lease-renewal request is received, Illuminates.One verifies the
request signature using the installation's stored public key and validates
the relevant protocol and identity bindings. Historical lease timing,
request frequency and similar behavioural evidence are recorded, but they
do not determine whether a new lease is issued during M0.1.

If:

``` text
authorization_status = AUTHORIZED
```

Illuminates.One issues a fresh signed 24-hour authorization lease.

If:

``` text
authorization_status = LOCKED
```

Illuminates.One returns a signed lock response rather than a lease.

A signed lock response can contain:

``` json
{
  "authorized": false,
  "decision": "LOCKED",
  "reason_code": "INSTALLATION_REVIEW_REQUIRED",
  "display_message": "This Lumen installation is currently locked. Please contact Illuminates.One for assistance.",
  "contact_email": "lumen@illuminates.one"
}
```

The decision, reason code, researcher-facing message and contact email must
all be inside the Illuminates.One signed payload. Licentia transports the
response without interpreting it, and Servire verifies the signature before
using or displaying any of these values.

The M0.1 authorization contact address is:

``` text
lumen@illuminates.one
```

The address is managed independently of Lumen through Illuminates.One email
routing, so its forwarding destination can change without changing the
authorization protocol or distributed Lumen software.

The installation record should keep administrative lock information
separate from the researcher-facing response, for example:

``` json
{
  "authorization_status": "LOCKED",
  "lock": {
    "reason_code": "INSTALLATION_REVIEW_REQUIRED",
    "display_message": "This Lumen installation is currently locked. Please contact Illuminates.One for assistance.",
    "contact_email": "lumen@illuminates.one",
    "internal_note": "Illuminates.One administrative information only",
    "locked_at": "UTC BSON Date",
    "locked_by": "administrator identifier"
  }
}
```

`internal_note` is Illuminates.One administrative data and must never be
returned to Servire.

`LOCKED` represents an explicit Illuminates.One administrative decision. It
must not be generated merely because an automated anomaly threshold was
crossed.

Servire continues attempting authorization for as long as Servire is
running, including while locally `EXPIRED` or `LOCKED`. Neither state is a
terminal protocol state.

If an administrator changes:

``` text
authorization_status: LOCKED
```

to:

``` text
authorization_status: AUTHORIZED
```

the next valid Servire renewal request receives a fresh signed lease and
Servire returns to `AUTHORISED` automatically. No special unlock protocol,
reinstallation, re-registration or Servire restart is required.

## 9. M0.1 Observation-First Policy

M0.1 is the first real external research use of this authorization
system. Actual usage patterns are not yet sufficiently understood to
justify automatic punitive rules.

The governing principle is:

> **Anomaly is evidence, not denial. Denial is an explicit
> Illuminates.One administrative decision.**

The process is:

``` text
Observe
   ↓
Record
   ↓
Persist
   ↓
Identify patterns
   ↓
Flag possible anomalies
   ↓
Human assessment
   ↓
Learn what actually matters
   ↓
Only later define automated policy
```

An observed fact, an anomaly and a security conclusion are not
equivalent.

For example:

``` text
source IP changed
       ↓
observed fact

same runtime appears from a different IP
       ↓
possible anomaly

VPN / network transition / clone / other cause
       ↓
requires assessment
```

During M0.1, unusual behaviour should normally continue to receive
authorization while being flagged for review.

Potential observations include:

-   unusually high lease-request frequency;
-   concurrent runtime IDs;
-   source-IP changes;
-   machine-fingerprint changes;
-   unusual `runtime_auth_sequence` behaviour;
-   `run_counter` behaviour;
-   duplicate request IDs;
-   duplicate challenges;
-   repeated invalid signatures;
-   overlapping runtime/lease activity;
-   the same installation appearing concurrently from different IP
    addresses;
-   unexpected distribution or software versions.

Even stronger clone-like evidence should initially be surfaced for human
assessment rather than automatically locking the installation.

------------------------------------------------------------------------

## 10. MongoDB Data Model

The authorization database should begin with five collections:

``` text
releases
    └── authoritative registry of recognised Lumen releases

researchers
    │
    └── registration_keys
              │
              └── lumen_installations

authorization_events
    └── technical evidence linked principally by installation_id
```

`releases` is reference/configuration data rather than authorization
telemetry. Keeping recognised releases in MongoDB avoids hard-coding release
knowledge into the authorization service.

### 10.1 `releases`

Purpose: authoritative registry of Lumen releases recognised by
Illuminates.One.

Example:

``` json
{
  "release_id": "M01",
  "release_version": "M0.1",
  "distribution_id": "lumen-research-m0.1",
  "status": "ACTIVE",
  "released_at": "UTC BSON Date"
}
```

For registration-key validation, Illuminates.One compares the key's release
component with this registry. A syntactically valid but unrecognised release
does not automatically deny M0.1 registration; it produces the
`UNKNOWN_RELEASE` observation and is flagged for review.

The release encoded in the registration key and the signed request's
`distribution_id` / version can also be compared. A mismatch is useful
authorization evidence and should be recorded as an observation rather than
silently discarded.

### 10.2 `researchers`

Purpose: minimal administrative identity and contact information for
people entitled to participate in the research release.

Example:

``` json
{
  "researcher_id": "uuid",
  "name": "Researcher Name",
  "email": "researcher@example.org",
  "organisation": "Optional Organisation",
  "status": "ACTIVE",
  "created_at": "UTC BSON Date",
  "updated_at": "UTC BSON Date"
}
```

`organisation` is optional.

Technical authorization events should not duplicate the researcher's
name, email address or organisation.

### 10.3 `registration_keys`

Purpose: authoritative record of issued and encountered one-time
registration credentials and their registration history.

Example:

``` json
{
  "registration_key": "LUMEN-M01-....",
  "researcher_id": "uuid-or-null",
  "status": "KNOWN",
  "first_seen_status": "KNOWN",
  "issued_at": "UTC BSON Date",
  "first_seen_at": "UTC BSON Date",
  "used_at": "UTC BSON Date",
  "installation_id": "uuid-or-null",
  "installation_public_key": "...",
  "review_required": false,
  "reviewed_at": null,
  "reviewed_by": null,
  "notes": null
}
```

A pre-issued key starts as `KNOWN`.

A structurally valid key that Illuminates.One has never issued can be
inserted as:

``` text
researcher_id = null
status = UNKNOWN
first_seen_status = UNKNOWN
review_required = true
```

If later accepted as legitimate:

``` text
status = KNOWN
review_required = false
```

`first_seen_status` remains `UNKNOWN`, preserving history.

### 10.4 `lumen_installations`

Purpose: authoritative current state for each cryptographically
registered Lumen installation.

Example:

``` json
{
  "installation_id": "uuid",
  "installation_public_key": "...",
  "researcher_id": "uuid-or-null",
  "distribution_id": "lumen-research-m0.1",
  "lumen_version": "M0.1",
  "registered_at": "UTC BSON Date",
  "last_seen_at": "UTC BSON Date",
  "authorization_status": "AUTHORIZED",
  "lock": {
    "reason_code": null,
    "display_message": null,
    "contact_email": "lumen@illuminates.one",
    "internal_note": null,
    "locked_at": null,
    "locked_by": null
  },
  "current_lease_id": "uuid",
  "lease_issued_at": "UTC BSON Date",
  "lease_expires_at": "UTC BSON Date",
  "total_authorization_requests": 27,
  "total_successful_requests": 26,
  "total_failed_requests": 1,
  "last_runtime_id": "uuid",
  "last_runtime_auth_sequence": 3,
  "last_source_ip": "x.x.x.x",
  "last_machine_fingerprint": "...",
  "run_counter": 27
}
```

`lumen_installations` is authoritative for the installation/public-key
binding.

The precise semantics of `run_counter` must be taken from the current
Servire implementation before persistence logic is coded. It must not be
assumed to mean the same thing as `runtime_auth_sequence`.

### 10.5 `authorization_events`

Purpose: append-only operational evidence for authorization activity.

It should record successful and unsuccessful attempts wherever enough
information is available to create a meaningful event.

Example:

``` json
{
  "event_id": "uuid",
  "installation_id": "uuid-or-null",
  "request_id": "uuid-or-null",
  "request_type": "initial_registration",
  "received_at": "UTC BSON Date",
  "source_ip": "x.x.x.x",
  "runtime_id": "uuid-or-null",
  "runtime_auth_sequence": 1,
  "run_counter": 27,
  "machine_fingerprint": "...",
  "distribution_id": "lumen-research-m0.1",
  "lumen_version": "M0.1",
  "servire_version": "0.8.25",
  "signature_valid": true,
  "registration_key_status": "KNOWN",
  "decision": "AUTHORIZED",
  "lease_id": "uuid",
  "lease_issued_at": "UTC BSON Date",
  "lease_expires_at": "UTC BSON Date",
  "review_required": false,
  "observations": []
}
```

Events may include observations such as:

``` text
UNKNOWN_RELEASE
UNKNOWN_REGISTRATION_KEY
RELEASE_DISTRIBUTION_MISMATCH
HIGH_LEASE_REQUEST_RATE
CONCURRENT_RUNTIME_IDS
SOURCE_IP_CHANGED
MACHINE_FINGERPRINT_CHANGED
DUPLICATE_REQUEST_ID
DUPLICATE_CHALLENGE
INVALID_SIGNATURE
```

These are evidence/observations, not automatic lock decisions.

The raw registration key must not be stored in `authorization_events`.

------------------------------------------------------------------------

## 11. Suggested MongoDB Indexes

Initial indexes should include:

``` text
releases
    UNIQUE release_id
    UNIQUE distribution_id

researchers
    UNIQUE researcher_id
    email as appropriate for administration

registration_keys
    UNIQUE registration_key
    researcher_id
    installation_id
    status

lumen_installations
    UNIQUE installation_id
    researcher_id
    authorization_status

authorization_events
    UNIQUE event_id
    request_id / replay-detection index
    installation_id + received_at
    received_at
    runtime_id
    source_ip
```

The exact uniqueness policy for `request_id` should be finalized
alongside replay handling.

------------------------------------------------------------------------

## 12. Source IP

Illuminates.One should retain the server-observed source IP as useful
operational evidence.

The public route is:

``` text
Internet HTTPS :443
       ↓
     HAProxy
       ↓
Illuminates.One nginx :8080
       ↓
illuminates-auth :8081
```

The authorization application must not blindly trust arbitrary
client-provided forwarding headers.

The trusted HAProxy/nginx chain must be configured so the authorization
service derives the originating address only from trusted proxy
information.

Source IP is an observation, not installation identity.

It may be used to identify unusual behaviour but must not automatically
lock an M0.1 installation.

------------------------------------------------------------------------

## 13. Privacy Boundary

The design intentionally separates personally identifying administrative
data from technical authorization evidence.

``` text
authorization_event
       │ installation_id
       ▼
lumen_installation
       │ researcher_id
       ▼
researcher
```

This means routine telemetry does not need to contain researcher names
or email addresses.

For the initial research release, collect only information with a clear
operational purpose.

Before broader public registration, Illuminates.One will need to address
appropriate privacy documentation and policy, including matters such as:

-   what personal information is collected;
-   why it is collected;
-   retention;
-   access;
-   correction/deletion requirements where applicable;
-   operational/security telemetry;
-   researcher communication.

Those policy decisions are outside the immediate D5 implementation, but
the data model should make them easier rather than harder.

------------------------------------------------------------------------

## 14. Licentia Boundary

Authorization traffic is direct private HTTP between Servire and
Licentia and HTTPS from Licentia to Illuminates.One.

Licentia answers only:

> **Did I obtain an Illuminates.One response?**

Servire answers:

> **Does that response authorize this Lumen installation?**

Licentia must not:

-   own the installation private key;
-   own the Illuminates.One verification key;
-   interpret authorization decisions;
-   determine `AUTHORIZED`, `GRACE`, `EXPIRED` or `LOCKED`;
-   manufacture authorization responses.

It transports the signed messages.

------------------------------------------------------------------------

## 15. Current Proven Baseline

As of 2026-09-19, the following signed exchange has been proven
end-to-end:

``` text
Servire
  ↓
creates and signs initial-registration request
with installation private key
  ↓
Licentia
  ↓
opaque relay over HTTPS
  ↓
Illuminates.One
  ↓
verifies installation request signature
  ↓
creates 24-hour authorization lease
  ↓
signs response with Illuminates.One private key
  ↓
Licentia
  ↓
opaque relay
  ↓
Servire
  ↓
verifies Illuminates.One signature
and request/installation/challenge/distribution/UTC bindings
  ↓
accepts authorization lease
```

The next stage is to replace the current proof-stage registration
behaviour with persistent Illuminates.One registration and renewal
semantics.

------------------------------------------------------------------------

## 16. Next Implementation Slice

The next implementation work should remain on the Illuminates.One side
first.

1.  Add MongoDB configuration and connectivity without hard-coded
    credentials.
2.  Create the five collections and indexes:
    -   `releases`
    -   `researchers`
    -   `registration_keys`
    -   `lumen_installations`
    -   `authorization_events`
3.  Add the M0.1 release record, the initial researcher and the issued
    registration key for the M0.1 researcher.
4.  Implement registration-key structural validation, including the fixed
    `LUMEN` product identifier and release component.
5.  Implement `UNKNOWN_RELEASE` and `UNKNOWN_REGISTRATION_KEY` observations,
    known/unknown registration-key persistence, and review flagging.
6.  Implement atomic initial registration and installation/public-key
    binding.
7.  Persist authorization events and current lease state.
8.  Implement `lease_renewal` using the stored installation public key
    and no registration key.
9.  Capture source IP through the trusted proxy chain.
10. Add duplicate/replay observations and other evidence without
    automatic lockout.
11. Prove:
    -   initial registration with a known key;
    -   initial registration with a structurally valid unknown key;
    -   initial registration for a structurally valid but unknown release;
    -   retention of both `UNKNOWN_RELEASE` and
        `UNKNOWN_REGISTRATION_KEY` when both apply;
    -   rejection of blank/malformed key;
    -   subsequent renewal without registration key or supplied public
        key;
    -   persistence of all relevant evidence;
    -   signed lease verification by Servire.

Only after the Illuminates.One authority side is stable should the
Servire startup gate and complete authorization state/recovery behaviour
be implemented.

------------------------------------------------------------------------

## 17. M0.1 Policy Summary

The M0.1 authorization design can be summarized as:

> **Register the researcher minimally. Issue a one-time registration
> key. Establish a cryptographic installation identity on first use.
> Thereafter authorize the installation, not the bootstrap credential.
> Illuminates.One's persistent installation decision is `AUTHORIZED` or
> `LOCKED`; Servire owns lease, grace and expiry runtime state. Record enough
> evidence to understand real-world behaviour. Treat anomalies as
> observations requiring human assessment. Only an explicit Illuminates.One
> administrative decision locks an installation. Servire continues seeking
> authorization while it is running, allowing normal recovery whenever
> Illuminates.One returns the installation to `AUTHORIZED`.**
