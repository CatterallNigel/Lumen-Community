# Lumen M0.1 Phase 11 --- Distribution Architecture, Docker Packaging and Runtime Security Plan

**Date:** 2026-09-16\
**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)
**Target:** Lumen External Research Distribution M0.1\
**Roadmap phase:** Phase 11 --- Runtime Authorization and Distribution
Security


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## 1. Purpose

The existing Phase 11 roadmap checklist defines high-level
runtime-authorization and code-protection objectives, but it does not
describe the engineering work required to produce an installable
external research distribution.

Phase 11 therefore needs to cover two related concerns:

1.  **Distribution architecture and packaging** --- how the complete
    M0.1 environment is packaged, networked, configured and exposed on a
    researcher's machine.
2.  **Runtime authorization and distribution security** --- how an
    installation is identified, authorised by Illuminates.One, permitted
    to start protected Lumen services, and prevented from operating
    indefinitely outside the authorised runtime path.

These should be implemented as explicit N11.x stages rather than one
large security task. M0.1 remains a **single-host research
distribution**.

## 2. Proposed M0.1 Distribution Boundary

### 2.1 Bundled components

The Dockerised distribution should include:

-   Servire
-   Pontis
-   Rogare
-   Vestigare
-   Repetere
-   Fiducia
-   Moderari
-   Praebere
-   Nuntius
-   Licentia
-   MongoDB
-   Pi, as the supported M0.1 Rogare tool provider
-   HAProxy, as the sole supported external Lumen application ingress and reverse-proxy layer

All bundled components should communicate over a dedicated private Lumen
Docker network.

### 2.2 Ollama remains external

Ollama is **not** part of the Lumen distribution. Lumen must not
install, start, stop or assume process ownership of Ollama.

The researcher supplies an operational Ollama installation reachable
from Lumen. Lumen must not assume that Ollama is on the same host or
necessarily uses port `11434`. Port `11434` remains the default, but the
endpoint must be configurable.

## 3. Proposed Network Boundary

``` text
Researcher's machine
│
├── Browser
│      │ HTTPS
│      ▼
│   HAProxy
│      │ private HTTP
│      ▼
│   Servire
│
├── Local MongoDB client / research tooling
│      │
│      ▼
│   127.0.0.1:27018
│      │
│      ▼
│   MongoDB container :27017
│
└──────────────────────── Docker boundary
                         │
                  private Lumen network
                         │
      ┌──────────────────┼───────────────────┐
      │                  │                   │
   Servire             Pontis              Rogare
   Nuntius             Moderari            Vestigare
   Repetere            Fiducia             Praebere
   MongoDB             Pi                  HAProxy
                                             │
                                             ▼
                                      configured Ollama
                                      endpoint

Licentia also requires outbound HTTP/HTTPS access to Illuminates.One. Servire does not communicate directly with Illuminates.One; it obtains authorization state from Licentia over the private Lumen Docker network.
```

The private network does not mean containers have no outbound
connectivity. Required outbound connections include Praebere →
configured Ollama endpoint and Licentia → Illuminates.One.

The security objective is that internal Lumen service ports are not
unnecessarily published to the host or local network.

## 4. Host-Accessible Services

### 4.1 Servire

Servire is the supported researcher/operator UI. Browser access should
be:

``` text
Browser → HTTPS → HAProxy → private HTTP → Servire
```

Servire itself does not need to own TLS certificate issuance or
management.

### 4.2 MongoDB

MongoDB is intentionally available to the researcher for inspection of
persisted Trace, Experiment, Run and other research evidence.

The distribution should map:

``` text
127.0.0.1:27018 → MongoDB container:27017
```

Port `27018` avoids collision with an existing MongoDB using host port
`27017`. Binding to `127.0.0.1` is preferred for M0.1 so the database is
available to local research tools without unnecessary LAN exposure.

MongoDB uses its normal wire protocol, not HTTPS.

### 4.3 Internal services

Unless a separately agreed M0.1 client requirement requires otherwise,
internal ports for Pontis, Rogare, Vestigare, Repetere, Fiducia,
Moderari, Praebere, Nuntius, Licentia and Pi should not be published from Docker.

### 4.4 Pontis external-client boundary requires final confirmation

The current M0.1 requirements describe Pontis host port `11435` as an
external-client entry point. The proposed distribution aims to expose
only Servire through HAProxy/HTTPS and MongoDB locally on `27018`.

This is a genuine release-boundary decision. If supported external
clients remain required, an explicit secure Pontis ingress must be
designed rather than simply publishing the internal Pontis port.

## 5. HAProxy Ingress and Deferred HTTPS/TLS

HAProxy remains part of the M0.1 Docker distribution, but HTTPS/TLS is **not required for M0.1**.

For M0.1, HAProxy is the sole supported Lumen application ingress:

```text
Researcher / external client
        │ HTTP
        ▼
     HAProxy
        │ private Docker network
        ├────────► Servire
        └────────► Pontis
```

Servire and Pontis remain private Docker services; their normal service ports are not published directly to the host. Where practical, one HAProxy host port with path-based routing should be preferred, subject to validation against the existing APIs.

MongoDB remains a deliberate separate local research-data endpoint on `127.0.0.1:27018`.

### 5.1 HTTPS/TLS is deferred

TLS certificate generation, local trust-store installation, browser certificate handling and renewal add deployment complexity that is not justified for the controlled M0.1 research release.

HTTPS/TLS is therefore deferred to later general research/external distribution hardening. Retaining HAProxy means TLS can later be introduced without changing the internal Lumen architecture:

```text
M0.1:  Client → HTTP  → HAProxy → Lumen
Later: Client → HTTPS → HAProxy → Lumen
```

When TLS is introduced, HAProxy should own TLS termination.

## 6. Ollama Endpoint Configuration

Because Ollama is external, its endpoint must be researcher-configurable
through the existing Praebere surface in Servire.

A simple M0.1 UI is:

``` text
Ollama Endpoint

Host:  [ localhost ]
Port:  [ 11434     ]

       [ Test Connection ]   [ Apply ]
```

### 6.1 Default

The researcher-facing default is:

``` text
localhost:11434
```

### 6.2 Docker host resolution

Inside a container, `localhost` means the container itself. The
distribution should hide this implementation detail where practical.

If the researcher enters `localhost:11434` and Ollama is on the physical
host, the Dockerised runtime should translate or resolve that meaning to
the appropriate host gateway, for example `host.docker.internal` in the
supported Docker Desktop environment.

The researcher should not normally need to know Docker's internal
hostname.

### 6.3 Remote/non-standard Ollama

Host and port must both be editable. Examples:

``` text
localhost : 11434
192.168.1.50 : 11434
ollama-lab : 11434
192.168.1.50 : 12345
```

### 6.4 Test Connection

**Test Connection** should:

-   test the proposed endpoint without changing active configuration;
-   verify that a suitable Ollama endpoint is reachable;
-   provide clear success/failure feedback;
-   not alter model selection/reservation/residency state; and
-   not silently persist the tested endpoint.

### 6.5 Apply

**Apply** should:

-   validate host and port;
-   persist the endpoint as authoritative Praebere configuration;
-   make subsequent provider operations use it; and
-   trigger or explicitly request the normal model-catalogue refresh.

### 6.6 Safe endpoint changes

The endpoint must not be changed underneath an incompatible
active/reserved model lifecycle.

The safe workflow is:

``` text
no active/reserved model
        ↓
edit endpoint
        ↓
Test Connection
        ↓
Apply
        ↓
refresh model catalogue
        ↓
normal model selection
```

The compatibility check should use Praebere's existing authoritative
lifecycle state rather than introducing an independent UI lock.

## 6.7 D5 Authorization Integration Baseline

Stage D5 introduces the runtime authorization service boundary before the full cryptographic authorization protocol is implemented.

The first Illuminates.One implementation is deliberately minimal: it accepts a Licentia authorization POST and returns a deterministic successful JSON response. This provides a real external endpoint against which Licentia can be developed and tested before installation identity, signing, leases and heartbeat behavior are added.

For D5:

- **Illuminates.One** provides the initial authorization endpoint.
- **Licentia** owns all communication with Illuminates.One.
- **Servire** starts/checks Licentia and consumes Licentia authorization state over private HTTP.
- **Nuntius / `\\obt`** is not part of the authorization path.
- **HAProxy** does not expose or route Licentia.
- If authorization cannot be established during Servire startup, Servire remains available to present an authorization-failure screen, while protected Stack startup is withheld.
- The failure UI should distinguish authorization failure from normal Stack operation and provide a retry path. Later stages may distinguish denial, unreachable service, expired authorization and grace-state conditions.

This D5 baseline proves the complete runtime path:

```text
Servire → Licentia → Illuminates.One → Licentia → Servire
```

before cryptographic identity and lease enforcement are layered onto it.

## 7. Proposed Phase 11 Engineering Stages

### N11.1 — Distribution Architecture and Security Boundary

Define and sign off the **single authorised Lumen Docker stack instance** as the M0.1 deployment boundary, together with bundled components, external dependencies, Docker topology, private networking, HAProxy ingress, HAProxy routing to Servire and Pontis, MongoDB access on `127.0.0.1:27018`, required outbound connectivity, volumes, Pi packaging and the external Ollama boundary.

**Exit condition:** one agreed deployment, ingress and security-boundary architecture exists before implementation begins.

### N11.2 — Dockerise and Package the Runtime

Create reproducible Docker images and the distribution-level Docker Compose definition for all Lumen services, MongoDB, Pi and HAProxy. Define runtime users, configuration locations, startup commands, health checks, volumes, logging and build/version metadata. Remove development-machine filesystem assumptions.

**Exit condition:** the complete distribution can be built and started reproducibly from the release package.

### N11.3 — Private Docker Network and HAProxy Ingress

Implement a dedicated private Lumen Docker network. Internal Lumen services must not publish their normal ports directly to the host.

HAProxy is the sole supported Lumen application ingress and proxies the explicitly supported external surfaces:

- Servire;
- Pontis.

MongoDB remains separately available to local research tooling through:

```text
127.0.0.1:27018 → MongoDB:27017
```

Required outbound connectivity remains available for Praebere → configured Ollama and Servire → Illuminates.One HTTPS.

**Exit condition:** HAProxy is the only Lumen application ingress, MongoDB is deliberately available locally, and protected service communication remains inside the Docker stack.

### N11.4 — External Ollama Endpoint Configuration

Implement the Praebere surface in Servire with:

- default `localhost:11434`;
- editable host and port;
- Docker host-gateway handling;
- remote/non-standard endpoint support;
- **Test Connection** without changing active state;
- **Apply** with persistence;
- model-catalogue refresh after Apply;
- clear failure reporting; and
- prevention of unsafe endpoint changes while Praebere lifecycle state is incompatible.

**Exit condition:** the same distribution can use host-local, remote or non-standard-port Ollama without researcher code/config-file editing.

### N11.5 — Installation Identity and Provisioning

Define and implement Distribution ID, Service Group UUID, installation-specific cryptographic identity, key generation/provisioning, identity persistence and public-identity registration with Illuminates.One.

The identity represents the authorised **Lumen Docker stack installation**, not a rigid physical-machine fingerprint. The Service Group UUID is an identifier, not an authentication secret.

**Exit condition:** each authorised Lumen Docker stack has a unique cryptographic identity recognised by Illuminates.One.

### N11.6 — Licentia and Illuminates.One Authorization Protocol

Introduce **Lumen Licentia** as the dedicated authorization service. Licentia owns the external authorization relationship with Illuminates.One; Servire does not implement the Illuminates.One protocol directly.

Licentia is started and supervised by Servire as an authorization prerequisite. Communication between Servire and Licentia uses a purpose-built private HTTP API on the Lumen Docker network. Authorization must **not** be transported through Nuntius or the `\\obt` operational messaging path.

Specify and implement the signed Licentia ↔ Illuminates.One authorization protocol, including request/response schemas, installation authentication, signing and verification, nonce/challenge freshness, timestamps/clock tolerance, failure semantics and server-side installation state.

```text
Servire                 Licentia                    Illuminates.One
   │                        │                              │
   │ authorize/status       │                              │
   ├───────────────────────►│ signed request               │
   │                        │ identity + UUID + nonce      │
   │                        ├─────────────────────────────►│
   │                        │                              │
   │                        │ signed authorization lease   │
   │                        │◄─────────────────────────────┤
   │ authorization state    │                              │
   │◄───────────────────────┤                              │
```

Licentia has no externally published port and is not routed through HAProxy. Its external traffic is outbound to Illuminates.One only.

**Exit condition:** Licentia establishes verifiable authorization with Illuminates.One, rejects invalid, stale or replayed responses, and exposes authoritative authorization state to Servire over the private Docker network.

### N11.7 — Authorization Lease State Machine

Implement in Licentia explicit `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE` and `EXPIRED` states.

Define lease duration, renewal interval, grace duration, startup behaviour, transient network-failure behaviour, expiry/restart semantics and deliberate heartbeat-suppression behaviour.

**Exit condition:** Licentia maintains authoritative lease state, temporary connectivity loss is bounded, and heartbeat suppression cannot provide indefinite normal operation.

### N11.8 — Servire-Authorised, Stack-Bound Protected-Service Startup

Implement short-lived startup authorization over the private Docker network so that each protected service can establish that:

1. Licentia has established that the installation is currently authorised by Illuminates.One;
2. Servire is authorising this service startup now;
3. the service belongs to the same authorised Docker stack instance; and
4. the authorization is fresh and cannot simply be replayed.

The authorization may bind values such as:

```text
installation_id
service_group_uuid
deployment_id
service_name
issued_at
expires_at
nonce
```

Include stack/deployment identity, short validity, service-side validation, installation/deployment/service binding, replay resistance, failure reporting, Servire-controlled startup and rejection of unsupported direct startup as an authorised external runtime.

This is the principal M0.1 control reinforcing the **single authorised Docker stack instance** boundary. It should not depend on fragile physical-machine fingerprinting.

**Exit condition:** protected services operate through the authorised Servire startup path as members of the authorised Docker stack and reject unsupported or stale startup authorization.

### N11.9 — External Research Distribution Build

Produce the researcher deliverable containing/providing Docker Compose, Lumen images/build artifacts, MongoDB, Pi, HAProxy, Licentia, provisioning tooling, configuration templates, Ollama endpoint setup, volume definitions, startup/shutdown and authorization procedures, researcher documentation, MongoDB access instructions and release/version information.

The package must not depend on the developer's source-tree layout or machine state.

**Exit condition:** a researcher can provision and operate M0.1 from the release package and documented prerequisites.

### N11.10 — Distribution and Security Validation

Validate at least:

- clean-machine installation and restart;
- startup/shutdown and persistence;
- MongoDB access on `127.0.0.1:27018`;
- HAProxy routing to Servire and Pontis;
- inability to reach protected service ports directly;
- host-local, remote, non-standard and unavailable Ollama endpoints;
- Ollama Test Connection and Apply;
- installation identity;
- valid/invalid/stale/replayed Licentia ↔ Illuminates.One authorization;
- Servire startup behavior when Licentia authorization succeeds, fails or is unavailable;
- lease renewal, grace and expiry;
- deliberate heartbeat suppression;
- direct protected-service startup attempts;
- startup with another deployment identity;
- copied distribution/installation behaviour;
- absence of Illuminates.One private signing material, permanent authorization secrets and hard-coded bypasses; and
- the complete Lumen research regression workflow.

**Exit condition:** the packaged candidate satisfies the distribution/security requirements and is ready for Phase 12 formal integrated acceptance.

## 8. M0.1 Security Model

M0.1 security is based on three reinforcing controls.

### 8.1 Single authorised Docker stack and controlled ingress

The supported runtime is one authorised Lumen Docker stack instance. HAProxy is its sole Lumen application ingress and proxies Servire and Pontis. Internal services remain private to the Docker network.

### 8.2 Renewable runtime authorization

The installation has a cryptographic identity registered with Illuminates.One. Licentia obtains and renews a signed, time-bounded authorization lease and exposes the resulting authorization state to Servire over the private Lumen Docker network. Possession of the package/images alone is insufficient for indefinite authorised operation.

### 8.3 Servire-authorised, stack-bound service startup

After Licentia has established current authorization, authorised Servire issues short-lived startup authorization to protected services over the private Docker network. That authorization binds each service to the authorised installation/deployment and current startup event.

Together these controls protect the **authorised Docker stack instance** rather than attempting to protect ordinary configuration files or rigidly fingerprint physical hardware.

## 9. Configuration Security Boundary

### 9.1 Protected configuration encryption is not required for M0.1

The normal Lumen `config.yaml` files do not contain information whose confidentiality justifies a configuration encryption/decryption subsystem.

M0.1 therefore does **not** encrypt ordinary service configuration at rest and does not implement runtime configuration unlocking.

This avoids unnecessary encryption/decryption lifecycle code, key derivation/storage, master-unlock mechanisms, recovery complexity and additional external-deployment failure modes.

### 9.2 Actual secrets remain protected

Cryptographic secrets must not be placed in ordinary `config.yaml` files.

Installation private-key material and transient authorization credentials require appropriate dedicated storage/runtime handling. The Illuminates.One private signing authority must never be present in the distributed installation.

## 10. Explicit Non-Goals

Phase 11 does not attempt to provide:

- HTTPS/TLS for M0.1 local research ingress;
- encrypted ordinary `config.yaml` files;
- absolute tamper resistance on researcher-controlled hardware;
- physical-machine fingerprint enforcement;
- a hardware trust boundary or general DRM;
- distributed multi-host Lumen deployment;
- automatic Ollama installation/lifecycle management;
- general PKI/certificate-management functionality;
- commercial multi-user licensing; or
- Aestimare.

HTTPS/TLS remains appropriate later hardening. Because HAProxy is already the ingress boundary, it can be added later without redesigning the internal services.

## 11. Proposed Sequence

```text
N11.1   Distribution architecture and security boundary
   ↓
N11.2   Dockerise/package runtime
   ↓
N11.3   Private Docker network + HAProxy ingress
   ↓
N11.4   Configurable external Ollama endpoint
   ↓
N11.5   Installation identity/provisioning
   ↓
N11.6   Illuminates.One authorization protocol
   ↓
N11.7   Authorization lease state machine
   ↓
N11.8   Servire-authorised, stack-bound service startup
   ↓
N11.9   External research distribution build
   ↓
N11.10  Distribution/security validation
   ↓
Phase 12 Formal Integrated M0.1 Acceptance
```

This ordering establishes the Docker deployment boundary before implementing the authorization mechanisms that protect it, while deliberately avoiding configuration-encryption and TLS complexity that are not justified for M0.1.
