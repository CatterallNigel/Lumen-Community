# Lumen M0.1 --- Licence Presentation and Acceptance Requirements

**Status:** M0.1 Distribution Requirement\
**Applies to:** Servire / Lumen M0.1 Research Distribution\
**Implementation point:** Complete after the Lumen Research Licence v0.1
and the applicable Pi licence have been frozen, and before creation of
the final M0.1 distribution.

## 1. Purpose

Servire shall present the Lumen M0.1 Research Licence to the researcher
before the first registration and authorization request is made.

Licence acceptance is an installation-level prerequisite for initial
registration and subsequent use of the Lumen Stack.

The same licence shall remain available for later review from the
Servire user interface.

## 2. Licence Material

Servire shall contain a dedicated licence directory containing the
release licence material.

The M0.1 licence material shall include:

-   **Lumen Research Licence --- M0.1 v0.1**
-   **Pi licence applicable to the exact Pi version included with M0.1**

The licence material packaged with the release shall be treated as
immutable release content.

The Lumen licence shall state that Rogare uses Pi and that use of Rogare
is subject to the applicable Pi licence terms. Researchers who use Lumen
exclusively through an external client and do not use Rogare do not use
Pi through Lumen.

## 3. Pi Licence Presentation

For M0.1, the preferred presentation is to include the applicable Pi
licence as an **appendix to the Lumen Research Licence**, while
retaining the original Pi licence text and copyright notice unchanged.

The appendix shall be clearly identified as third-party licence material
and shall not be presented as part of the Lumen licence terms
themselves.

A suitable structure is:

-   Lumen Research Licence --- M0.1 v0.1
-   Appendix A --- Pi Third-Party Licence
    -   Pi component/version identification
    -   Original copyright notice
    -   Original licence text

The exact licence text and copyright notice shall be taken from the Pi
package/version actually included in the final M0.1 distribution.

A separate `PI_LICENSE.txt` may also be retained in the licence
directory for packaging clarity and third-party notice compliance.

## 4. First-Load Licence Gate

When Servire is opened for the first time and the installation has not
yet accepted the current Lumen licence, Servire shall display the
licence in a modal dialog.

This modal shall be shown **before the first registration or
authorization request to Illuminates.One**.

The modal shall contain:

-   title: **Lumen M0.1 Research Licence**;
-   the complete licence text in a scrollable area, including the Pi
    appendix;
-   an acceptance checkbox, initially unticked;
-   **Accept & Continue** and **Cancel** buttons.

Suggested checkbox text:

> I have read and accept the Lumen M0.1 Research Licence.

**Accept & Continue** shall remain disabled until the checkbox is
selected.

Selecting **Cancel** shall close or leave the installation in its
unaccepted state. Initial registration and authorization shall not
proceed and the Stack shall not be startable until the licence is
accepted.

## 5. Acceptance State

On acceptance, Servire shall persist sufficient state to establish which
release licence has been accepted.

At minimum:

``` yaml
licence:
  licence_id: lumen-research-m0.1-v0.1
  accepted: true
  accepted_at: <UTC timestamp>
```

The persisted `licence_id` shall identify the specific licence version
rather than recording only a Boolean acceptance flag.

This allows a later Lumen release carrying different licence terms to
determine that its licence has not yet been accepted.

## 6. Registration and Authorization Ordering

The required first-use sequence is:

1.  Servire starts in initial-registration mode.
2.  Servire determines that the current release licence has not been
    accepted.
3.  Servire displays the licence modal.
4.  The researcher reviews and accepts the licence.
5.  Servire persists the licence acceptance state.
6.  Only then may Servire make the initial registration/authorization
    request to Illuminates.One.
7.  Following successful authorization, normal Servire operation may
    continue.

No initial authorization call shall be made before Step 5 has completed
successfully.

## 7. Permanent Licence Link

Servire shall provide a clearly accessible **Licence** link in its
normal user interface.

Selecting **Licence** after acceptance shall reopen the **same licence
modal component** used during initial registration.

In review mode:

-   the complete licence remains visible;
-   the acceptance checkbox is shown **ticked**;
-   the checkbox is **disabled/greyed out**;
-   no new acceptance action is required;
-   the modal contains a single **OK** button.

Selecting **OK** closes the modal.

The purpose is to provide permanent access to the exact licence accepted
for the installed M0.1 release without maintaining a separate
licence-viewing interface.

## 8. M0.1 Scope

M0.1 requires only:

-   the frozen Lumen Research Licence v0.1;
-   the exact applicable Pi licence;
-   a dedicated Servire licence directory;
-   one reusable licence modal;
-   persisted versioned licence acceptance;
-   a gate preventing initial authorization before acceptance; and
-   a permanent Servire **Licence** link for later review.

No separate Pi acceptance dialog or Pi acceptance state is required. The
relationship between Rogare and Pi is declared by the Lumen Research
Licence.

## 9. Distribution Gate

This work shall be completed **after** the Lumen Research Licence v0.1
and Pi licence have been finalized, but **before** the final Lumen M0.1
distribution image/package is created.

The final distribution acceptance check shall confirm that:

-   the exact frozen licence shown by Servire is the licence shipped
    with the distribution;
-   the Pi licence corresponds to the exact Pi version shipped;
-   first-load acceptance occurs before registration/authorization;
-   acceptance survives restart;
-   the permanent Licence link reopens the modal in accepted/read-only
    mode; and
-   the final distribution contains the required licence files.
