# Illuminates.One D5.4 — MongoDB Setup (PRIVATE)

**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)

> Contains a live application credential. Keep private and do not commit to Git.


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## Application database

```text
Host: 192.168.0.17
Port: 27017
Database: lumen_auth
Username: lumen_auth
Password: bVaJwYhC4yavF8lRJ31sbRIOwCBsXy9C
Authentication database: lumen_auth
```

## One-time MongoDB user creation

Connect to `192.168.0.17` with an existing MongoDB administrator using your normal `mongosh` administration method, then run:

```javascript
use lumen_auth

db.createUser({
  user: "lumen_auth",
  pwd: "bVaJwYhC4yavF8lRJ31sbRIOwCBsXy9C",
  roles: [
    { role: "readWrite", db: "lumen_auth" }
  ]
})
```

The application user therefore has read/write access to `lumen_auth` and does not require administrative rights over other databases.

## Illuminates.One `.env`

Create `.env` beside `compose.yaml`:

```text
LUMEN_AUTH_MONGO_HOST=192.168.0.17
LUMEN_AUTH_MONGO_PORT=27017
LUMEN_AUTH_MONGO_DATABASE=lumen_auth
LUMEN_AUTH_MONGO_USERNAME=lumen_auth
LUMEN_AUTH_MONGO_PASSWORD=bVaJwYhC4yavF8lRJ31sbRIOwCBsXy9C
LUMEN_AUTH_MONGO_AUTH_SOURCE=lumen_auth
LUMEN_REGISTRATION_KEY=D5-DEVELOPMENT-REGISTRATION-KEY
```

The final line remains only because D5.4 intentionally leaves the proven D5.3 registration endpoint semantics unchanged. It will disappear when registration keys become Mongo-backed in the next slice.
