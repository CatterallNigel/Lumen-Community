# Lumen M0.1 Stage D5 --- Illuminates.One Authorization

**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)
**Scope:** Establish the authorization service boundary and prove the
complete Servire → Licentia → Illuminates.One runtime path before
implementing the full cryptographic authorization protocol.


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## 1. Purpose

Stage D5 introduces **Lumen Licentia** as the dedicated Lumen
authorization service.

The immediate objective is not to implement the complete M0.1
authorization security model. The objective is to establish and test the
correct service boundaries, startup behavior, network path and failure
behavior using a deliberately simple Illuminates.One authorization
endpoint.

Once that vertical slice is working, later work can add installation
identity, request signing, signed leases, renewal, grace/expiry behavior
and stack-bound protected-service startup without changing the
fundamental service boundary.

## 2. Architectural Boundary

``` text
                         Internet
                            │
                            ▼
                  ┌─────────────────────┐
                  │   Illuminates.One   │
                  │ Authorization API   │
                  └──────────┬──────────┘
                             │
                       outbound HTTP(S)
                             │
┌────────────────────────────┼─────────────────────────────┐
│ Lumen Docker Stack         │                             │
│                            ▼                             │
│                    ┌───────────────┐                     │
│                    │   Licentia    │                     │
│                    │ Authorization │                     │
│                    └───────┬───────┘                     │
│                            │ private HTTP                │
│                            ▼                             │
│                       ┌─────────┐                        │
│ Browser → HAProxy ───►│ Servire │                        │
│                       └────┬────┘                        │
│                            │                             │
│                      controls Stack                     │
│                            ▼                             │
│                  Pontis / Rogare / ...                  │
└──────────────────────────────────────────────────────────┘
```

### Responsibilities

**Illuminates.One** - Owns the external authorization decision/API. -
For the first D5 implementation, accepts an authorization POST and
returns a deterministic successful response. - Later becomes the
server-side authority for installation registration, signed
authorization leases and authorization state.

**Licentia** - Is the only Lumen service that communicates with
Illuminates.One for authorization. - Owns only the authorization
**transport/exchange** between Servire and Illuminates.One; it does
**not** own or determine Lumen authorization state. - Receives the
Servire-created authorization message, forwards that message to
Illuminates.One, receives the Illuminates.One reply and returns that
reply to Servire without making an authorization decision. - May report
transport/exchange outcomes such as upstream HTTP status, timeout,
connection failure and retry exhaustion. - Exposes a deliberately small
private HTTP API to Servire. - Is not exposed through HAProxy and has no
published host port. - Does not use Nuntius or `\obt` for authorization
transport or state.

**Servire** - Starts/supervises Licentia as an authorization
prerequisite. - Generates a fresh cryptographically random authorization
challenge for each authorization attempt. - Sends that challenge to
Licentia over the private Docker network. - Independently verifies the
authorization proof returned by Illuminates.One, including its
signature, challenge binding, installation binding and freshness once
the full protocol is implemented. - Continues protected Stack startup
only when verification succeeds. - Remains available when authorization
fails so that it can display the authorization-failure UI.

**Nuntius** - Has no role in establishing or transporting
authorization. - `\obt` is explicitly outside the authorization path.

**HAProxy** - Remains the supported inbound Lumen application ingress. -
Does not route to Licentia. - Has no role in the outbound Licentia →
Illuminates.One authorization exchange.

## 3. D5 Initial Protocol

The first Illuminates.One endpoint should be deliberately small.

Suggested endpoint:

``` text
POST /api/lumen/authorize
```

The endpoint should accept a valid JSON POST body containing at least a
Servire-generated challenge. Even though cryptographic identity is a
later stage, the challenge/response shape should be established in D5 so
that the service interfaces do not need to change when signing is
introduced.

Initial successful response:

``` json
{
  "authorized": true,
  "message": "OK",
  "challenge": "<servire-generated-challenge>"
}
```

Using structured JSON and echoing the Servire challenge now avoids
changing the fundamental request/response path when the protocol later
becomes cryptographically protected. In D5 the challenge is only echoed;
it is **not yet a security control** because the response is unsigned.

For this first implementation, D5 does **not** require:

-   installation cryptographic identity;
-   Distribution ID validation;
-   Service Group UUID validation;
-   request signing;
-   server response signing;
-   nonce/challenge handling;
-   replay protection;
-   authorization leases;
-   renewal heartbeat;
-   grace periods;
-   expiry enforcement; or
-   protected-service startup tokens.

Those are layered onto the proven D5 boundary in later authorization
stages.

## 4. Licentia Private API

Licentia is an authorization transport broker, not an
authorization-state authority.

Servire creates the authorization message and, once the full
cryptographic protocol is introduced, signs it before sending it to
Licentia. Licentia forwards that message to Illuminates.One, receives
the Illuminates.One reply and returns the reply to Servire. Servire
alone interprets and validates the authorization semantics.

Licentia therefore does **not** expose an authorization-status endpoint
and does not maintain `AUTHORIZED`, `UNAUTHORIZED`, `GRACE` or `EXPIRED`
authorization states.

The private API can remain deliberately small:

``` text
GET  /health
POST /authorization/authorize
```

`GET /health` reports whether Licentia itself is alive/available. It
does not report whether Lumen is authorized.

`POST /authorization/authorize` performs one authorization exchange:

``` text
Servire-created request
        ↓
Licentia
        ↓
Illuminates.One
        ↓
Illuminates.One reply
        ↓
Licentia
        ↓
Servire
```

For the initial D5 implementation Licentia can behave very close to a
transparent application-level proxy: receive a JSON body, POST the same
body to the configured Illuminates.One authorization endpoint, receive
the reply, and return the reply to the caller. It remains a dedicated
service boundary so transport policy, retries, logging and future
protocol handling can be added without moving the trust decision out of
Servire.

Licentia may know and report **exchange outcomes**:

``` text
upstream response received
upstream HTTP 2xx
upstream HTTP 4xx
upstream HTTP 5xx
timeout
connection failure
retrying
retry exhausted
```

These are transport/protocol outcomes, not authorization states.

Licentia should retry transient timeout/connectivity failures according
to a bounded transport retry policy. Once that policy is exhausted, it
returns a clear transport failure to Servire.

An upstream `404`, `5xx`, timeout or connection failure does **not**
itself mean `GRACE`. Licentia reports what happened; Servire applies its
authorization state machine using its previously verified authorization
proof, if any.

``` text
Licentia reports failed/unavailable exchange
                ↓
Servire examines its last verified authorization proof
                ↓
        ┌───────┴────────┐
        │                │
valid lease remains   no valid lease
        │                │
   AUTHORISED       UNAUTHORISED /
                        EXPIRED
        │
lease expires
        │
      GRACE
        │
grace expires
        │
     EXPIRED
```

The authorization state machine belongs to Servire:

``` text
UNAUTHORISED
AUTHORIZING
AUTHORISED
GRACE
EXPIRED
```

Licentia does not need to interpret whether the Illuminates.One payload
says `authorized: true`, `DENIED`, `REVOKED` or any future authorization
semantic. Its job is to carry the exchange reliably and return the
Illuminates.One response to Servire for validation and interpretation.

## 5. Servire Startup Behavior

Authorization is a prerequisite for protected Stack startup.

Conceptual sequence:

``` text
Servire starts
    │
    ├── prerequisite checks
    │
    ├── MongoDB
    │
    ├── start/check Licentia
    │
    ├── generate fresh challenge
    │
    ├── request authorization(challenge)
    │      │
    │      └── Licentia → Illuminates.One
    │                       │
    │                       └── response bound to challenge
    │
    ├── Servire validates response/proof
    │
    ├── AUTHORIZED?
    │      │
    │      ├── YES → continue normal Stack startup
    │      │
    │      └── NO  → withhold protected Stack startup
    │                and show authorization failure UI
    │
    └── normal operation
```

Licentia is therefore not simply another ordinary Stack service. It is
an authorization transport broker and startup prerequisite. The
authorization lifecycle and final trust decision remain in Servire:
Licentia carries the exchange, while Servire validates and interprets
the proof issued by Illuminates.One before protected Stack operation may
proceed.

## 6. Trust, Sniffing and Replay Boundary

The Licentia → Servire network hop must not become the root of trust. A
simple Licentia response such as `AUTHORIZED` could be observed and
replayed by someone with sufficient access to the local Docker
environment.

The full protocol therefore uses end-to-end cryptographic proof between
Servire and Illuminates.One, with Licentia acting as the broker:

``` text
Servire                                  Illuminates.One
   │                                            │
   │ fresh challenge                           │
   ├────────► Licentia ───────────────────────►│
   │                                            │
   │                    signed authorization    │
   │                    bound to challenge      │
   │◄──────── Licentia ◄───────────────────────┤
   │                                            │
   └── independently verifies proof             │
```

The intended full design uses asymmetric cryptography rather than a
reusable shared secret:

-   Servire/installation possesses installation-specific private key
    material that is not given to Licentia.
-   Illuminates.One knows the corresponding registered public identity
    and can verify installation-authenticated requests.
-   Illuminates.One signs authorization responses with its private
    signing key.
-   Servire contains/trusts the corresponding Illuminates.One public
    verification key.
-   Each authorization attempt includes a fresh Servire-generated random
    challenge/nonce.
-   The Illuminates.One signed proof binds that challenge together with
    installation/deployment identity and issue/expiry information.
-   A captured Licentia → Servire response therefore cannot simply be
    reused for a later authorization challenge.
-   Licentia possesses neither the Servire installation private key nor
    the Illuminates.One private signing key and therefore cannot
    manufacture a valid fresh proof.

For D5, the Illuminates.One stub merely echoes the challenge and returns
`authorized: true`. This proves the end-to-end message shape but **does
not yet provide cryptographic protection against sniffing or replay**.
D5 must not describe that stub as secure authorization. The signing and
identity stages convert the same interface into the actual security
control.

## 7. Authorization Failure UI

If authorization fails during Servire startup, Servire must remain
operational enough to display a dedicated failure screen similar in
purpose to the existing MongoDB connection failure screen.

Initial wording can communicate that authorization could not be
established without incorrectly implying that the installation has
necessarily been denied.

Example:

``` text
Lumen Authorization Unavailable

This Lumen installation could not be authorised by Illuminates.One.

Please check the network connection and try again.

[ Retry Authorization ]
```

The initial D5 UI needs:

-   clear authorization failure state;
-   no normal protected Stack startup;
-   retry authorization action;
-   useful diagnostic/logging information for the operator.

Later stages can distinguish explicit denial, Illuminates.One
unavailable, invalid identity, expired authorization, grace state and
other protocol-specific failures.

## 8. Network Requirements

Licentia runs only on the private Lumen Docker network.

Required path:

``` text
Servire ──private HTTP──► Licentia ──outbound HTTP(S)──► Illuminates.One
```

Not permitted/supported:

``` text
External client ─X─► Licentia
HAProxy         ─X─► Licentia
Nuntius/\obt   ─X─► authorization transport
```

No Licentia service port should be published to the host.

## 9. D5 Implementation Stages

### D5.1 --- Minimal Illuminates.One Authorization Endpoint

Implement the server-side endpoint that:

-   accepts a POST from Licentia;
-   validates that the request is syntactically acceptable;
-   receives a Servire-generated challenge relayed by Licentia;
-   returns HTTP success with
    `{ "authorized": true, "message": "OK", "challenge": "<same challenge>" }`;
-   logs the authorization request sufficiently for development/testing;
-   contains no real licensing decision yet.

**Exit condition:** the endpoint can be called independently with
Postman or equivalent HTTP tooling and consistently returns the expected
structured authorization response, including the supplied challenge.

### D5.2 --- Licentia Service Skeleton and Relay Proof

Create the standalone Lumen Licentia service with:

-   normal Lumen service structure/conventions where applicable;
-   configuration for the Illuminates.One authorization URL;
-   private HTTP listener;
-   `/health`;
-   `/authorization/authorize`;
-   bounded timeout/retry handling;
-   logging and clear transport/error reporting;
-   no authorization state machine.

Before Servire integration, prove Licentia independently using Postman
or equivalent HTTP tooling.

``` text
Postman
   ↓
POST Licentia /authorization/authorize
   ↓
Licentia receives message
   ↓
Licentia POSTs same message to Illuminates.One
   ↓
Illuminates.One returns response
   ↓
Licentia receives response
   ↓
Licentia returns response to Postman
```

At this stage Licentia can intentionally be close to a transparent
proxy. The purpose is to prove the service boundary, outbound
connectivity, request preservation, response return path, timeout/retry
behavior and diagnostics before Servire is changed.

**Exit condition:** using Postman, a caller can send a test
authorization message to Licentia, observe that the same message reaches
the real Illuminates.One D5 endpoint, and receive the Illuminates.One
reply back through Licentia.

### D5.3 --- Licentia Transport Failure Behaviour

Prove the relay failure paths independently before Servire integration.

Licentia should:

-   preserve the caller request body when forwarding it;
-   return the Illuminates.One response body without manufacturing an
    authorization decision;
-   preserve or clearly expose the relevant upstream HTTP outcome;
-   retry bounded transient timeout/connectivity failures;
-   report retry exhaustion clearly;
-   distinguish upstream `4xx`, upstream `5xx`, timeout and connection
    failure for diagnostics;
-   never convert any transport failure into `AUTHORIZED`,
    `UNAUTHORIZED`, `GRACE` or `EXPIRED`.

The exact private Licentia response envelope for transport failures can
be finalized during implementation, but it must let Servire distinguish
a returned Illuminates.One response from failure to obtain one.

**Exit condition:** successful relay, upstream HTTP errors,
timeout/connectivity failures and bounded retry behavior are all proven
against standalone Licentia before Servire is modified.

### D5.4 --- Docker Integration

Add Licentia to the M0.1 Docker distribution:

-   private Lumen network membership;
-   no host-published port;
-   configuration/environment wiring;
-   health check;
-   logging;
-   appropriate Servire dependency/startup integration;
-   outbound network access to Illuminates.One.

**Exit condition:** Licentia operates inside the normal M0.1 Docker
runtime and can reach Illuminates.One.

### D5.5 --- Servire Authorization Integration

Integrate Servire directly with Licentia over private HTTP.

Servire should:

-   start/check Licentia;
-   generate a fresh authorization challenge;
-   request authorization through Licentia using that challenge;
-   receive the Illuminates.One response/proof from Licentia;
-   for D5, validate the response shape and that the echoed challenge
    matches the current challenge;
-   in the full protocol, independently verify the Illuminates.One
    signature, challenge, installation binding and expiry/freshness;
-   continue protected Stack startup only after successful validation;
-   own the authorization state machine (`UNAUTHORISED`, `AUTHORIZING`,
    `AUTHORISED`, `GRACE`, `EXPIRED`);
-   treat Licentia/upstream transport failures as exchange failures, not
    authorization decisions;
-   apply the current verified lease/grace rules when an exchange fails;
-   withhold protected Stack startup when no valid authorization/grace
    permits operation;
-   not use Nuntius or `\obt` for any part of this exchange.

**Exit condition:** successful authorization permits normal Stack
startup and failed authorization prevents it.

### D5.6 --- Servire Authorization Failure Screen

Implement the startup failure surface:

-   analogous to the existing MongoDB prerequisite-failure experience;
-   clearly identifies authorization as unavailable/failed;
-   keeps Servire available;
-   prevents access to normal protected Stack operation;
-   provides **Retry Authorization**;
-   reports useful diagnostic information without exposing secrets.

**Exit condition:** a researcher receives a clear, recoverable UI when
authorization cannot be established.

### D5.7 --- D5 End-to-End Validation

Validate at least:

1.  Illuminates.One reachable and returns authorized → Stack starts.
2.  Illuminates.One unreachable on initial authorization → Licentia
    retries according to policy; with no existing verified
    authorization, Stack does not start and failure UI appears.
3.  Illuminates.One returns HTTP `4xx`/`5xx` → Licentia reports the
    upstream outcome; Servire applies its existing verified lease/grace
    state if one exists.
4.  Illuminates.One returns malformed JSON → authorization fails safely.
5.  Illuminates.One returns `authorized: false` → authorization fails
    safely.
6.  Retry succeeds after an initial failure → Servire validates the
    returned response and normal startup can continue.
7.  Licentia is not reachable externally through HAProxy.
8.  Licentia has no published host port.
9.  Authorization traffic does not use Nuntius or `\obt`.
10. Existing Docker baseline remains operational after successful
    authorization.

**Exit condition:** the complete path below is demonstrated reliably:

``` text
Servire generates fresh challenge
   ↓
Licentia relays challenge
   ↓
Illuminates.One issues challenge-bound response/proof
   ↓
Licentia relays response/proof unchanged
   ↓
Servire validates response/proof
   ↓
authorised Stack startup
```

## 10. Deferred Authorization Work

After D5 proves the service boundary, subsequent work adds the actual
M0.1 authorization security mechanisms:

``` text
installation identity/provisioning
        ↓
signed end-to-end Servire ↔ Illuminates.One protocol via Licentia
        ↓
authorization lease
        ↓
renewal / heartbeat
        ↓
grace and expiry state machine
        ↓
Servire-authorised stack-bound service startup
        ↓
security validation
```

The important D5 architectural rule remains unchanged throughout those
stages:

> **Illuminates.One grants authorization and signs the authorization
> proof. Licentia transports the authorization exchange and reports
> transport outcomes but does not know or own Lumen authorization state.
> Servire creates/signs authorization requests, generates freshness
> challenges, owns the authorization state machine and independently
> verifies/interprets the Illuminates.One proof before controlling Stack
> startup. Other Lumen services do not communicate with
> Illuminates.One.**
