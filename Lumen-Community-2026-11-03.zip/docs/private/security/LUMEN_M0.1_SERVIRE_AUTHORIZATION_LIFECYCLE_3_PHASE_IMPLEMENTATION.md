# Lumen M0.1 --- Servire Authorization Lifecycle

**Status:** CLOSED — M0.1 scope implemented and live-proven (2026-09-19)


## Completion update — 2026-09-19

**Status: CLOSED for the M0.1 work covered by this document.**

The authorization work described here has now been implemented and live-proven through the completed D5/D5.5 and Servire authorization lifecycle work.

Final proven authorization behaviour includes:

- Mongo-backed researcher / registration / installation / authorization evidence foundation.
- Persistent Servire Ed25519 installation identity and immutable installation/public-key binding.
- Signed initial registration and signed lease renewal through Licentia.
- Licentia operating only as the transport/protocol broker; Servire independently verifies Illuminates.One decisions.
- Configurable authority lease duration and configurable Servire renewal/retry intervals, including fractional-hour test values.
- Servire registration evidence persisted separately from the memory-only current lease.
- Runtime states `UNAUTHORISED`, `AUTHORIZING`, `AUTHORISED`, `GRACE`, `EXPIRED`, and `LOCKED`.
- Live-proven `AUTHORISED → GRACE → EXPIRED → AUTHORISED` recovery.
- Live-proven signed `LOCKED` decision and `LOCKED → AUTHORISED` recovery without restarting Servire.
- Protected Stack authorization gating and recovery behaviour.
- Servire Phase 3 authorization UI, including the permanent compact Authorization panel and live state indication.
- Signed Illuminates.One LOCKED reason/message/contact information is presented by Servire rather than recreated locally.
- Final Servire authorization implementation: **0.8.29.5**.

Short development lease/renewal intervals may remain in use while integration testing continues. Before the M0.1 distribution is frozen, restore the intended production values: Illuminates.One lease **24 hours**, Servire renewal **6 hours**, unavailable retry **1 hour**.

Any remaining work described elsewhere for Docker packaging, HAProxy, final distribution assembly, or later hardening is outside the closure of the authorization implementation itself.

## Purpose

This document defines the remaining Servire-side authorization work for
Lumen M0.1 following completion of the Licentia D5.5 work and the
Illuminates.One Mongo-backed registration and configurable
lease-duration work.

The implementation is deliberately divided into three phases so that
each part can be proven independently before the next is introduced.

## Core Design Decisions

### Authority and trust

Illuminates.One is the authorization authority. Servire owns the
installation identity and verifies signed Illuminates.One responses.
Licentia remains only the authorization transport/protocol broker.

Servire must never infer authorization from locally editable state.
Authorization is accepted only from a response whose Illuminates.One
signature verifies successfully and whose identity/request bindings are
valid.

### Persistent installation identity

The long-lived installation identity remains persisted under:

``` text
data/identity/
    installation_id
    private_key.pem
    public_key.pem
```

The exact existing filenames should be retained where Servire already
defines them; the structure above is conceptual.

The installation private key remains local to Servire. The
`installation_id` is permanently associated with its Ed25519 public key
after successful initial registration.

### Persist only the original registration evidence

Servire will not persist the current authorization lease.

After the first successful `initial_registration`, Servire persists the
**complete signed Illuminates.One response exactly as received**:

``` text
data/authorization/
    registration.json
```

This file is registration evidence, not a reusable authorization lease.

On subsequent Lumen starts Servire:

1.  Loads `registration.json`.
2.  Verifies the Illuminates.One signature.
3.  Verifies that the signed installation identity matches the local
    installation identity.
4.  Uses the valid response only as evidence that initial registration
    previously succeeded.
5.  Immediately requests a fresh lease using `lease_renewal`.

The lease embedded in the original registration response may be expired.
Its expiry is irrelevant when the response is being used as registration
evidence.

If `registration.json` is missing, malformed, has an invalid signature,
or does not bind correctly to the local installation identity, Servire
does not treat the installation as proven registered and follows the
initial-registration path.

There is no locally trusted `registered=true` flag.

### Current lease is memory-only

The current signed lease is held in memory only.

Every Lumen restart requires Servire to contact Illuminates.One and
obtain fresh authorization before releasing the protected Stack.

This avoids stale persistent lease state and means a copied or edited
local lease file cannot be used because no such file exists.

### Authorization timing

Illuminates.One defines the actual validity period of a lease through
its signed `issued_at` and `expires_at` values. Servire must never
assume a 24-hour lease.

Servire controls when it asks for renewal.

The intended M0.1 defaults are:

``` yaml
authorization:
  renewal_interval_hours: 6
  unavailable_retry_interval_hours: 1
```

These values must be configurable and must not be hardcoded.

Both settings are **positive floating-point hours**, not integer-only
values. Fractional hours are explicitly supported so the real scheduler
and retry paths can be exercised quickly during development and manual
testing without changing the scheduling mechanism.

For example:

```yaml
authorization:
  renewal_interval_hours: 0.05
  unavailable_retry_interval_hours: 0.025
```

This represents a 3-minute normal renewal interval and a 1.5-minute
unavailable retry interval.

For faster development testing, approximately one-minute and thirty-second
intervals are also valid:

```yaml
authorization:
  renewal_interval_hours: 0.0167
  unavailable_retry_interval_hours: 0.0083
```

Servire must parse these settings as floating-point values and convert them
to its internal duration representation without truncating them to integer
hours. Each value must be greater than zero; there is no artificial
one-hour minimum.

The production M0.1 defaults remain `6` hours and `1` hour.

The renewal interval does not extend or redefine a lease. The signed
Illuminates.One `expires_at` is always authoritative.

### Runtime identity and sequence

`runtime_id` is generated afresh on every Servire process start and is
not persisted.

`runtime_auth_sequence` starts at `1` for each runtime and increments
for every authorization attempt, including:

-   initial registration;
-   normal lease renewal;
-   retry after unavailability;
-   recovery from GRACE;
-   recovery from EXPIRED;
-   recovery from LOCKED.

### Local authorization states

Servire uses:

``` text
UNAUTHORISED
AUTHORIZING
AUTHORISED
GRACE
EXPIRED
LOCKED
```

`LOCKED` may only result from a valid, signed Illuminates.One
authorization decision. A timeout, transport failure, malformed response
or unverifiable response must never produce `LOCKED`.

`GRACE` begins when a scheduled renewal cannot obtain a usable
authorization response because Illuminates.One is unavailable, while the
existing signed lease remains valid.

GRACE does **not** extend the lease.

The signed `expires_at` remains the hard authorization boundary.

Conceptually:

``` text
AUTHORISED
    |
    | scheduled renewal unavailable
    v
GRACE
    |
    +---- renewal succeeds ----------------> AUTHORISED
    |
    +---- signed lease expires ------------> EXPIRED
                                               |
                                               +---- later renewal succeeds
                                                          |
                                                          v
                                                     AUTHORISED
```

Servire continues authorization attempts while in GRACE, EXPIRED and
LOCKED so that recovery can occur without reinstalling or restarting
Lumen.

### UI requirements

The Servire UI must expose meaningful authorization state, including:

-   AUTHORISED
-   GRACE
-   EXPIRED
-   LOCKED

When in GRACE, the UI must provide a useful indication of the remaining
valid lease time, calculated from the signed `expires_at`.

For example:

``` text
Authorization: GRACE
Illuminates.One currently unavailable
Existing authorization remains valid

Lease expires: 2026-09-20 18:36 UTC
Time remaining: 17h 42m
Next retry: 43m
```

Where appropriate the UI should also expose the next renewal/retry time.

For a signed LOCKED response, Servire should display the user-facing
information supplied by Illuminates.One, including `display_message` and
`contact_email`.

------------------------------------------------------------------------

# Phase 1 --- Registration Persistence and Lease Renewal

## Objective

Prove the distinction between one-time initial registration and
subsequent lease renewal before introducing background scheduling.

## 1. Persist successful initial-registration evidence

After a successful `initial_registration`:

-   verify the Illuminates.One signature and all required bindings;
-   retain the current lease in memory;
-   create `data/authorization/` if required;
-   persist the complete original signed Illuminates.One response
    unchanged as `registration.json`.

Writing should be atomic so a process interruption cannot leave a
partially written registration record.

## 2. Validate registration evidence on startup

At Servire startup:

-   load the persistent installation identity;
-   inspect `data/authorization/registration.json`;
-   verify the Illuminates.One signature;
-   verify the response represents a successful initial registration;
-   verify the installation binding matches the current local
    installation identity.

Do not use the original response as the current lease on restart.

## 3. Implement `lease_renewal`

If valid registration evidence exists, the startup authorization request
becomes `lease_renewal`.

A renewal includes the required persistent and runtime identity
information, including:

-   `request_type=lease_renewal`;
-   `installation_id`;
-   current `lease_id` where one exists in the current runtime;
-   fresh `request_id`;
-   fresh challenge;
-   current `runtime_id`;
-   incremented `runtime_auth_sequence`;
-   relevant version/distribution/fingerprint metadata;
-   Servire signature.

A renewal must **not** send:

-   `registration_key`;
-   `installation_public_key`.

Illuminates.One looks up the public key already bound to the
installation and verifies the Servire signature with it.

## 4. Handle authoritative HTTP responses correctly

Servire must distinguish an authoritative Illuminates.One response from
transport unavailability.

A `409` or other usable response passed through by Licentia is not
automatically `NOT_AVAILABLE`.

Servire must parse and validate the response and handle its signed
authorization decision appropriately.

Only genuine Licentia/upstream unavailability is treated as
`NOT_AVAILABLE`.

## Phase 1 proof

Manually prove:

``` text
Fresh identity
    -> initial_registration
    -> signed authorization accepted
    -> registration.json persisted

Restart Servire
    -> registration.json verified
    -> lease_renewal sent
    -> no registration key/public key sent
    -> fresh signed lease accepted
```

Also prove that corrupted or mismatched registration evidence cannot
establish registered state.

Do not add the periodic scheduler until this lifecycle is proven.

------------------------------------------------------------------------

# Phase 2 --- Renewal Scheduler, State Machine and Recovery

## Objective

Turn the proven renewal protocol into the continuous Servire
authorization lifecycle.

## 1. Configurable timing

Add configuration for at least:

``` yaml
authorization:
  renewal_interval_hours: 6
  unavailable_retry_interval_hours: 1
```

Neither value is to be hardcoded into authorization behaviour. Both
accept positive fractional-hour values and must retain their fractional
precision when converted into scheduler durations. This allows the same
production scheduling code to be manually tested with minute- or
sub-minute intervals.

## 2. Immediate startup authorization

Every Servire runtime performs authorization during startup.

A previously registered installation performs an immediate renewal
rather than waiting for the normal renewal interval.

The protected Stack is not released merely because a previous runtime
once held a valid lease.

## 3. Background renewal lifecycle

After authorization succeeds:

-   schedule the next normal renewal;
-   ensure only one authorization scheduler is active;
-   increment `runtime_auth_sequence` for every attempt;
-   replace the in-memory current lease only after a new signed response
    has been successfully verified;
-   schedule retries appropriately after unavailability;
-   stop the scheduler cleanly during Servire shutdown.

## 4. AUTHORISED behaviour

A valid signed authorization lease places Servire in `AUTHORISED`.

The protected Stack may operate.

A successful renewal replaces the current in-memory lease and
returns/keeps Servire in `AUTHORISED`.

## 5. GRACE behaviour

If a scheduled renewal fails because authorization infrastructure is
unavailable, but the existing signed lease has not expired:

``` text
AUTHORISED -> GRACE
```

The protected Stack continues to operate.

Servire schedules the unavailable retry interval rather than waiting for
the next normal renewal interval.

The UI shows:

-   GRACE;
-   lease expiry;
-   calculated remaining authorization time;
-   next retry where available.

If a retry succeeds:

``` text
GRACE -> AUTHORISED
```

## 6. EXPIRED behaviour

If the current signed lease reaches `expires_at` without a replacement:

``` text
GRACE -> EXPIRED
```

The protected Stack is stopped or withheld.

Servire, Nuntius and Licentia remain available as required for
authorization recovery.

Servire continues authorization attempts.

A later valid authorization produces:

``` text
EXPIRED -> AUTHORISED
```

and permits the protected Stack to recover.

## 7. LOCKED behaviour

A valid signed Illuminates.One `LOCKED` decision produces:

``` text
* -> LOCKED
```

The protected Stack is stopped or withheld.

The response may include:

-   `reason_code`;
-   `display_message`;
-   `contact_email`.

These may be exposed appropriately in the Servire UI.

Servire continues making authorization requests while LOCKED.

If Illuminates.One later changes the installation to `AUTHORIZED`, a
subsequent valid renewal can produce:

``` text
LOCKED -> AUTHORISED
```

without reinstalling, re-registering or restarting Lumen.

## 8. Invalid responses

Invalid signatures, malformed responses, identity mismatches and
replay/binding failures must not manufacture authorization.

Their exact state-transition treatment should preserve any still-valid
previously verified lease where appropriate, while never extending its
signed expiry.

------------------------------------------------------------------------

# Phase 3 --- UI, Operational Integration and Lifecycle Verification

## Objective

Complete the operator-facing behaviour and prove the full authorization
lifecycle.

## 1. Authorization status UI

Expose at least:

``` text
AUTHORISED
GRACE
EXPIRED
LOCKED
```

The UI should provide useful context rather than only a status word.

For AUTHORISED, relevant information can include current lease expiry
and next planned renewal.

For GRACE, show:

-   Illuminates.One currently unavailable;
-   existing authorization remains valid;
-   exact lease expiry;
-   dynamically calculated time remaining;
-   next retry.

For EXPIRED, make clear that authorization has expired and the protected
Stack is unavailable while Servire continues recovery attempts.

For LOCKED, show the signed Illuminates.One user-facing message and
contact information.

## 2. Protected Stack lifecycle

Verify that authorization state controls the protected Stack correctly.

Nuntius and Licentia remain bootstrap/control-plane services necessary
for authorization.

Servire itself remains alive when authorization is unavailable, expired
or locked.

The remainder of the protected Stack operates only when the
authorization state permits it.

## 3. Licentia Clear Logs integration

Servire's **Clear Logs** operation must include Licentia.

Licentia now uses an active rotating log:

``` text
logs/licentia.log
```

with rotated backups.

Prefer clearing based on the service's configured log path/pattern
rather than hardcoding a fixed list such as `.1` through `.5`, so future
changes to Licentia's rotation count do not require another Servire
change.

## 4. Operational logging

Servire should clearly log authorization lifecycle events without
logging secrets.

Useful events include:

-   registration evidence loaded/verified;
-   initial registration requested/completed;
-   renewal requested/completed;
-   authorization state transitions;
-   scheduled renewal time;
-   unavailable retry;
-   lease expiry;
-   LOCKED decision;
-   recovery to AUTHORISED;
-   signature/binding validation failures.

Do not log private keys or registration credentials.

## 5. Required lifecycle tests

Before the Servire authorization work is considered complete, prove at
least:

1.  Fresh installation performs initial registration.
2.  Successful registration response is persisted as signed registration
    evidence.
3.  Restart verifies registration evidence and performs renewal rather
    than registration.
4.  Registration key and installation public key are absent from
    renewal.
5.  Successful scheduled renewal replaces the in-memory lease.
6.  Renewal interval is configurable.
7.  Unavailable retry interval is configurable.
8.  Scheduled renewal unavailable while lease valid enters GRACE.
9.  GRACE shows correct remaining lease validity.
10. Recovery from GRACE returns to AUTHORISED.
11. Lease expiry without renewal enters EXPIRED and protects the Stack.
12. EXPIRED continues retrying and can recover to AUTHORISED.
13. Signed LOCKED decision enters LOCKED.
14. LOCKED continues requesting authorization.
15. Changing authority-side status back to AUTHORIZED allows automatic
    recovery.
16. Invalid Illuminates.One signature cannot authorize.
17. Edited/corrupt registration evidence cannot establish registered
    state.
18. Installation identity mismatch in registration evidence is rejected.
19. `runtime_auth_sequence` increments for each attempt.
20. A new Servire runtime gets a new `runtime_id` and resets
    `runtime_auth_sequence` to 1.
21. Servire correctly distinguishes authoritative rejection from
    `NOT_AVAILABLE`.
22. Clear Logs clears Licentia active and rotated logs.

------------------------------------------------------------------------

# Implementation Sequence

The three phases should remain deliberately separate:

``` text
PHASE 1
Registration evidence + lease_renewal
        |
        | prove manually
        v
PHASE 2
Scheduler + state machine + recovery
        |
        | prove outage/expiry/lock lifecycle
        v
PHASE 3
UI + log integration + complete lifecycle verification
```

This avoids building scheduling and UI behaviour on top of an unproven
renewal protocol.

## M0.1 Security Boundary

The M0.1 design does not claim resistance to a hostile user with
complete administrative/root control of the host.

A user with full filesystem access may copy the installation private key
and identity. Encryption of local authorization files would not solve
that problem without introducing another protected key-storage
mechanism.

The M0.1 approach is therefore:

-   protect the installation private key as a secret;
-   verify all authoritative Illuminates.One responses
    cryptographically;
-   do not trust editable local authorization assertions;
-   persist only signed initial-registration evidence;
-   keep the current lease in memory;
-   obtain fresh authorization on every Lumen start;
-   record authority-side operational evidence for later clone/anomaly
    assessment.

The central rule is:

> **Persistent authorization state is evidence, not authority.
> Illuminates.One's verified signature makes it authoritative.**
