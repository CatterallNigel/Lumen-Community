# Lumen Repetere — Definitive Matched and Divergent Replay Behaviour

**Status:** CLOSED as implemented M0.1 Replay behaviour — retained as authoritative reference  
**Scope:** Lumen M0.1 Replay lifecycle  
**Agreed:** 9 September 2026


## Implementation closeout — 2026-09-19

The matched/divergent Replay behaviour defined here is now **CLOSED as implementation behaviour** and retained as the authoritative M0.1 reference.

The completed implementation establishes the fresh Replay session/model lifecycle, child Trace recording, private deterministic matched path, first-divergence fork, transparent divergent continuation, terminal result persistence and ordered Pontis/Praebere cleanup described here.

This does **not** close every Replay release-acceptance item. The dedicated outstanding-work checklist still retains the explicit prerequisite negative-path matrix, genuine cleanup/recovery-boundary acceptance, and final clean-start cross-service release-candidate pass. Those are acceptance tasks against this implemented behaviour, not unfinished definition of the behaviour itself.

## 1. Purpose

This document defines the required behaviour of Repetere for a non-divergent Replay and a divergent Replay. It is retained as the definitive reference for the implemented M0.1 behaviour.

The central distinction is:

- A non-divergent Replay remains private. Repetere replays and compares the recorded interaction without sending model traffic to Pontis or an external tool provider.
- A divergent Replay records the first behavioural difference and then changes into a transparent proxy. The actual divergent response is allowed to continue through the prepared Pontis tool-provider path until the complete ask-to-answer interaction ends.

A divergence is a comparison result. It is not an instruction to terminate the ask before its final answer.

## 2. Service ownership

### Repetere owns

- The Replay Experiment and Run.
- The source Trace and replay sequence.
- Comparison of live responses with recorded responses.
- First-divergence detection and evidence.
- Injection of recorded tool results while the Replay continues to match.
- The transition to transparent proxy behaviour after divergence.
- Starting and stopping the child Vestigare recording.
- Requesting creation and closure of its Pontis session.
- Persisting the terminal Run outcome.
- Responding to a Pontis session-termination notification by stopping Vestigare and marking the active Experiment execution as `TERMINATED`.

Repetere knows its Pontis session ID. It does not need to know Pontis's internal ACP session ID or ACP bookkeeping.

### Vestigare owns

- Recording the child Replay Trace.
- Binding the recording to the Repetere session, Experiment, Run and source Trace.
- Recording privately ingested matching exchanges.
- Transparently recording live traffic after divergence.
- Completing the recording when instructed by Repetere.

Vestigare does not decide whether a Replay matched, diverged or completed.

### Pontis owns

- The authoritative Lumen session.
- Establishing and maintaining the supported external tool provider's ACP connection associated with that session.
- Associating the external tool provider's HTTP traffic with the correct Lumen session.
- Coordinating model reservation and activation through Praebere.
- Detecting the ACP `end_turn` outcome after a divergent live continuation.
- Notifying Repetere that the divergent Replay conversation has completed.
- Accepting an operator close or force-close of a Repetere session and notifying Repetere that termination has been requested.
- Closing its session and internal ACP resources when Repetere requests session closure.
- Informing Praebere that the session has terminated.

Pontis does not decide the Replay result and does not stop Vestigare.

### Praebere owns

- Model selection, reservation and activation.
- Loading the selected model when required.
- Tracking every session using the model.
- Releasing a terminated session's reservation and execution.
- Unloading the model only when no other session still requires it.

### External tool provider

The external client and tool provider supported by Pontis is responsible only for:

- Executing tool requests it receives.
- Returning the resulting tool output through its normal HTTP provider request.

The external tool provider does not own the Replay, its continuation, its comparison state, its completion decision or the Lumen session lifecycle.

## 3. Common Replay preparation

Both Replay outcomes begin with the same preparation:

1. Repetere creates a new Run for the staged Experiment.
2. Repetere requests a fresh Pontis session with origin `repetere`.
3. Pontis creates the authoritative Lumen session.
4. Pontis establishes and binds the corresponding external tool-provider ACP connection without requiring Repetere to submit a conversational ask to Pontis.
5. Pontis associates the external tool provider's HTTP traffic with the Repetere session.
6. Pontis coordinates reservation and activation of the recorded model through Praebere.
7. Praebere loads the model if it is not already resident.
8. Pontis confirms that the Repetere session is ready.
9. Repetere starts a child Vestigare Trace bound to the session, Experiment, Run and source Trace.

The ACP tool-provider route is prepared at this stage but remains dormant during a completely matching Replay. No canned prompt or additional conversational ask may be used merely to create the ACP connection because that would alter context and contaminate the child Trace.

## 4. Non-divergent Replay

A non-divergent Replay is private. No model response or tool request is passed to Pontis.

1. Repetere constructs the first live model request from the recorded source exchange.
2. Repetere sends the request directly to Moderari using the fresh Replay session identity.
3. Moderari calls the model and returns the live response to Repetere.
4. Repetere compares the live response with the corresponding recorded response.
5. Repetere records the live request and response in the child Trace through Vestigare's private recording-ingestion path.
6. If the matched response contains a tool request:
   - Repetere does not pass the tool request to Pontis.
   - Repetere takes the recorded tool result from the source Trace.
   - Repetere injects that recorded tool result into the next live model request.
7. Repetere repeats the private request, response, comparison and recording cycle for every recorded exchange.
8. The final live response matches the recorded final response.
9. Repetere confirms that all meaningful source exchanges have been reproduced and matched.
10. Repetere sets the Run result to `MATCHED`.
11. Repetere tells Vestigare to stop recording.
12. Vestigare completes and persists the child Trace.
13. Repetere tells Pontis to close the Replay session.
14. Pontis closes the Lumen session and its internal ACP resources.
15. Pontis tells Praebere that the session has terminated.
16. Praebere releases the session's model execution and reservation.
17. Praebere unloads the model if no other session requires it.
18. Repetere persists the terminal Run state as `MATCHED · COMPLETED`.

During a completely matching Replay:

- Pontis receives no model traffic.
- Pontis carries no Replay model traffic.
- No live tool is executed.
- Recorded tool results provide deterministic continuation.

Repetere determines completion because it owns the source sequence and knows when every meaningful recorded exchange has matched.

## 5. Divergent Replay

A divergent Replay begins privately and follows the non-divergent sequence until the first meaningful mismatch.

1. Repetere constructs and sends recorded exchanges privately to Moderari.
2. Repetere compares and privately records each live response.
3. Recorded tool results continue to be injected while the interaction matches.
4. Repetere detects the first meaningful difference between a live response and its recorded counterpart.
5. Repetere persists the first-fork evidence, including the expected and observed behaviour.
6. Repetere marks the Run as divergent but still running.
7. Repetere stops comparison and stops injecting recorded continuation data.
8. The actual divergent model response is passed unchanged into the already-prepared route:

   `Repetere -> Vestigare -> Pontis -> external tool provider`

9. Repetere becomes a transparent proxy. It does not interpret, alter or compare subsequent conversation messages.
10. Vestigare transparently records the live divergent continuation.
11. If the divergent response requests a tool, the external tool provider executes the real tool.
12. The external tool provider returns the tool result in its next HTTP request through:

   `External tool provider -> Pontis -> Vestigare -> Repetere -> Moderari`

13. The model response returns through:

   `Moderari -> Repetere -> Vestigare -> Pontis -> external tool provider`

14. The standard request path may contain any number of further model responses and external tool executions.
15. Repetere and Vestigare remain transparent throughout this continuation; Vestigare continues recording it.
16. When the complete interaction ends, Pontis detects ACP `stop_reason=end_turn`.
17. Pontis sends Repetere a session-scoped notification that the Replay conversation has completed.
18. Repetere sets the Run result to `DIVERGED`.
19. Repetere tells Vestigare to stop recording.
20. Vestigare completes and persists the full child Trace, including the complete divergent result.
21. Repetere tells Pontis to close the Replay session.
22. Pontis closes the Lumen session and its internal ACP resources.
23. Pontis tells Praebere that the session has terminated.
24. Praebere releases the session's model execution and reservation.
25. Praebere unloads the model if no other session requires it.
26. Repetere persists the terminal Run state as `DIVERGED · COMPLETED`.

The first divergence is retained as comparison evidence, while the entire subsequent interaction is retained as the divergent result.

## 6. Conversation-completion authority

An individual HTTP or SSE response completing does not necessarily mean that the conversation has completed. A response may request one or more tools; after the external tool provider returns the tool output, the model interaction continues through another request.

The relevant signals are:

| Signal | Meaning | Whole divergent conversation complete? |
| --- | --- | --- |
| HTTP/SSE response ends | One model invocation completed | No |
| Model `finish_reason: tool_calls` | The external tool provider must execute one or more tools | No |
| ACP tool result completed | One tool execution completed | No |
| Another request carries an external tool result | The interaction is continuing | No |
| Model `finish_reason: stop` | The model produced a response requiring no tool | Supporting evidence only |
| ACP `stop_reason=end_turn` | The complete interaction ended | Yes |

Pontis owns ACP and therefore owns detection of `end_turn`. Repetere does not inspect or validate ACP internals. It receives only the session-scoped completion notification required to finish its Run.

## 7. Cleanup rules

Cleanup preserves service ownership:

1. Repetere determines that the matched Replay is complete, or receives Pontis's completion notification for a divergent Replay.
2. Repetere stops Vestigare.
3. Repetere asks Pontis to close its session.
4. Pontis closes its own Lumen and ACP resources.
5. Pontis informs Praebere that the session has terminated.
6. Praebere releases the model execution and reservation.
7. Praebere decides whether the model can be unloaded.

Pontis detecting `end_turn` does not itself start cleanup. It notifies Repetere. Repetere then initiates the ordered shutdown.

Cleanup operations must ultimately be idempotent so that ordinary completion, cancellation, timeout and recovery cannot leave Vestigare recording, Moderari waiting, a Pontis session open or a Praebere execution reserved indefinitely.

## 8. Pontis operator termination

An operator must be able to terminate a stuck Replay by closing or force-closing its Repetere-owned session in Pontis.

The termination sequence is:

1. The operator selects **End Session** or **Force Close** for the Repetere session in Pontis.
2. Pontis identifies the session as owned by Repetere.
3. Pontis sends Repetere a session-scoped termination notification containing the Repetere session ID.
4. Repetere stops the associated Vestigare child recording.
5. Vestigare completes the child Trace as a terminated recording while retaining everything captured before termination.
6. Repetere marks the active Replay Experiment execution and Run as `TERMINATED`; it must not report `MATCHED` or `DIVERGED · COMPLETED`.
7. Repetere acknowledges the termination and requests or confirms closure of its Pontis session.
8. Pontis closes the authoritative Lumen session and its internal ACP resources.
9. Pontis informs Praebere that the session has terminated.
10. Praebere releases that session's model execution and reservation.
11. Praebere unloads the model if no other session requires it.

**End Session** uses this sequence as a coordinated graceful termination. **Force Close** sends the same termination notification but must not remain blocked indefinitely waiting for Repetere. After a bounded acknowledgement period, Pontis completes its own session and Praebere cleanup. Repetere must treat the notification idempotently and complete its Vestigare and persistence responsibilities when the notification is received or during recovery.

Closing the Pontis session is therefore an authoritative external cancellation of the associated Replay, not merely removal of a Pontis UI record.

## 9. Required terminal outcomes

- Full comparison with no divergence: `MATCHED · COMPLETED`.
- First divergence followed by a complete transparent continuation: `DIVERGED · COMPLETED`.
- Operator close or force-close through Pontis: `TERMINATED`.
- A divergence alone is not completion; the live continuation and final answer must be recorded first.
- A stalled or failed continuation must not be reported as successfully completed and must enter an explicit failed, timed-out or cancelled terminal state after bounded recovery and cleanup.

## 10. Implementation invariant

The definitive invariant is:

> Repetere privately reproduces and compares recorded behaviour while it matches. At the first divergence, it preserves the fork and becomes transparent so the real ask can continue through its tools and final answer. The external tool provider executes requested tools, Vestigare records the evidence, Pontis owns the session and ACP boundary, and Praebere owns the model lifecycle.
