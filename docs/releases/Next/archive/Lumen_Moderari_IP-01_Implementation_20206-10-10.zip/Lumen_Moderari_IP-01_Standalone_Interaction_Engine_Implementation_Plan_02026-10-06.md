# Lumen Moderari Redesign --- IP-01 Implementation Plan

## Moderari Standalone Interaction Engine: CIM, Adapter and Filter Foundations

**Date:** 02026-10-06\
**Status:** Revised implementation planning baseline\
**Scope:** Moderari Standalone Interaction Engine (SIE), developed
independently before Lumen Stack integration

------------------------------------------------------------------------

# 1. Purpose

IP-01 establishes the Moderari Standalone Interaction Engine (SIE)
outside the running Lumen Stack.

SIE is the interaction-processing boundary used by Moderari Core.
Moderari Core passes interaction material into SIE; SIE determines
whether no processing is required or whether discovered Adapters and/or
Filters must participate, owns all CIM traversal and Filter loopback,
and returns the resulting interaction material to Moderari Core.

SIE is deliberately a framework rather than a collection of hard-coded
protocol or Filter behaviours. It knows the contracts and structures
required to discover, validate, instantiate and invoke components, but
it does not know what an individual Adapter or Filter does.

The foundation must therefore allow Base Adapters, Specialised Adapters
and Filters to be self-describing and naturally extensible without
changing SIE framework code.

At configuration time SIE may evaluate discovered Filter requirements
against the current Effective Model Definition (EMD) supplied by
Praebere. This result is transient and is not retained as model
knowledge or a persistent model-to-Filter compatibility catalogue.

At first Ask, once the client representation is known, SIE revalidates
the current configuration, resolves the required Adapter/Filter paths,
contributes to materialisation of the immutable Session Execution Plan,
and creates a minimal hot session-scoped Execution Instance keyed by
`session_id`.

Subsequent interactions use that already-resolved Execution Instance.
The EMD is not repeatedly supplied or re-evaluated for every Ask. The
Execution Instance is disposable runtime machinery and is destroyed when
the session ends.

IP-01 remains independently testable without a running Praebere, Pontis,
Rogare, Vestigare, Repetere, Nuntius or live provider.

------------------------------------------------------------------------

# 2. Architectural Baseline

The consolidated architecture documents are authoritative for IP-01:

-   `Lumen_Moderari_Redesign_Proposal_02026-10-03_Consolidated.md`
-   `Lumen_Moderari_Adapter_Architecture_02026-10-03_Consolidated.md`
-   `Lumen_Moderari_Filter_Architecture_02026-10-03_Consolidated.md`
-   `Lumen_Moderari_Canonical_Interaction_Model_Architecture_02026-10-03_Consolidated.md`
-   `Lumen_Praebere_Rogare_Pontis_Vestigare_Repetere_Companion_Changes_02026-10-03_Consolidated.md`
-   `Lumen_Moderari_Standalone_Interaction_Engine_Base_Architecture_02026-10-06.md`

The previous high-level implementation plan remains useful background,
but IP-01 deliberately changes the implementation sequence by developing
the Adapter, CIM and Filter foundations before Praebere integration.

The following boundaries are fixed:

> **Praebere Model Profile = knowledge**\
> **Moderari Adapter = compatibility**\
> **Moderari Filter = executable intentional transformation**\
> **Moderari Filter Profile = user configuration convenience**

For IP-01, Praebere knowledge is represented by synthetic test inputs.
IP-01 must not implement competing provider/model knowledge.

------------------------------------------------------------------------

# 3. Implementation Principles

## 3.1 Standalone First

The interaction engine must be executable and testable without:

-   Praebere;
-   Pontis;
-   Rogare;
-   Nuntius;
-   Vestigare;
-   Repetere;
-   Servire;
-   MongoDB;
-   Ollama;
-   Colibri; or
-   any live model.

External-service facts are supplied through explicit test fixtures or
harness inputs.

## 3.2 Preserve M0.1

The current `main` branches remain the M0.1 Research Foundation Build.

IP-01 is developed on the Moderari redesign branch. Equivalent redesign
branches may exist in the other Lumen services, but IP-01 should not
require changes to them.

## 3.3 No Architecture-by-Implementation

Implementation convenience must not alter established responsibility
boundaries.

In particular:

-   Filters must not use CIM.
-   CIM must not contain provider/model quirks.
-   Praebere concepts must not be reimplemented inside Moderari.
-   Pontis must not become a representation classifier.
-   Adapter translation must not become intentional interaction
    transformation.
-   Filter transformation must not be treated as representation
    translation.

## 3.4 Explicit Failure

Unsupported, ambiguous or incompatible paths must produce explicit typed
results/errors.

The implementation must not silently:

-   guess an interaction representation;
-   discard documented semantics;
-   substitute an Adapter;
-   substitute a Filter;
-   bypass mandatory Filter loopback;
-   introduce model-specific compensation into Core; or
-   reinterpret missing provider-representation knowledge as client
    `Unknown`.

## 3.5 Deterministic Resolution

Given the same:

-   installed extension set;
-   client representation result;
-   provider representation;
-   provider identifier;
-   model identifier;
-   Adapter Enabled/Disabled state;
-   selected Filters; and
-   Effective Model Definition,

the engine must resolve the same execution path.

------------------------------------------------------------------------

# 4. IP-01 Scope

IP-01 contains the following implementation areas:

``` text
Moderari Standalone Interaction Engine (SIE)
│
├── Core ↔ SIE Boundary
│   ├── interaction entry/exit contract
│   ├── Adapter IN/OUT semantics relative to CIM
│   ├── first-Ask materialisation
│   └── session-scoped Execution Instance lifecycle
│
├── Component Framework
│   ├── component identity/version
│   ├── self-description / manifests
│   ├── restart-based discovery
│   └── registration
│
├── Representation Framework
│   ├── discovered representation identities
│   ├── request recognition
│   └── Unknown handling
│
├── CIM
│   ├── Lumen-defined schema/version
│   ├── semantic objects
│   └── validation
│
├── Adapter Framework
│   ├── Base Representation Adapter contract
│   ├── Specialised Adapter contract
│   ├── registry/discovery
│   ├── deterministic path resolution
│   └── bidirectional representation ↔ CIM translation
│
├── Filter Framework
│   ├── registry/discovery
│   ├── required EMD attribute declaration
│   ├── transient applicability evaluation
│   ├── execution mode
│   ├── private model-interaction support
│   └── filter_execution_id
│
├── SIE Execution
│   ├── normal client ↔ provider processing
│   ├── mandatory Filter loopback
│   ├── private Filter model-interaction routing
│   └── hot per-session Execution Instance
│
└── Standalone Harness
    ├── synthetic EMD/session inputs
    ├── request fixtures
    ├── extension fixtures
    └── acceptance scenarios
```

The framework owns structure, discovery, routing and execution topology.
It does not own the semantics of concrete Adapters, Filters or EMD
attributes.

  -----------------------------------------------------------------------
  \# 5. Explicitly Out of Scope

  IP-01 does **not** implement:

  \- Praebere session reservations; - Praebere Effective Model Definition
  construction; - provider lifecycle or model activation; - Pontis
  session routing; - Nuntius `\obt` transport; - Rogare session
  configuration UI; - Servire administration UI; - Vestigare transport or
  persistence; - Repetere replay orchestration; - complete
  Moderari/Pontis session lifecycle; - persistence of Session Execution
  Plans; - construction of the EMD; - production MongoDB persistence; -
  live Ollama/Colibri execution; - hot loading/unloading of Python
  extensions; - third-party Base Representation Adapters; - arbitrary CIM
  extension by plugins; - response-direction Filters; - Filter Profile
  administration UI; or - final policy for every possible lossy
  published-representation conversion.

  IP-01 may define data structures that later services will consume, but
  it must not prematurely implement those services.
  -----------------------------------------------------------------------

# 6. Proposed Internal Package Boundary

The exact filenames may change during implementation. The important
boundary is that SIE framework code is independent from concrete Adapter
and Filter implementations.

``` text
moderari/
└── interaction/
    ├── components/
    │   ├── identity.py
    │   ├── manifest.py
    │   ├── discovery.py
    │   └── registry.py
    │
    ├── representations/
    │   ├── contract.py
    │   ├── registry.py
    │   └── recognition.py
    │
    ├── cim/
    │   ├── schema.py
    │   ├── models.py
    │   ├── validation.py
    │   └── version.py
    │
    ├── adapters/
    │   ├── base.py
    │   ├── specialised.py
    │   ├── registry.py
    │   ├── discovery.py
    │   ├── resolver.py
    │   └── execution.py
    │
    ├── filters/
    │   ├── contract.py
    │   ├── registry.py
    │   ├── discovery.py
    │   └── execution.py
    │
    ├── execution/
    │   ├── instance.py
    │   ├── engine.py
    │   └── errors.py
    │
    └── harness/
        ├── fixtures/
        ├── scenarios/
        └── runner.py
```

Concrete Lumen Base Adapters, Specialised Adapters and Filters may
initially ship in the same repository/package, but they are
implementations of the framework contracts and must not be hard-coded
into framework resolution.

Representation identities are contributed by discovered Base Adapter
implementations rather than enumerated in SIE framework code.

The purpose of this structure is separation of responsibility, not
directory structure for its own sake.

------------------------------------------------------------------------

# 7. Core Standalone Input Model

The standalone harness supplies synthetic inputs corresponding to
information that the integrated Stack will later provide.

Configuration-time inputs include:

``` text
session_id
provider identifier
provider interaction representation
provider model identifier
current Effective Model Definition (EMD)
Adapter Enabled / Disabled state
selected Filter configuration, or None
```

The EMD is authoritative input from Praebere. SIE does not construct it,
interpret the provenance of its values, or define a model-characteristic
ontology.

A Filter may declare the names of EMD attributes it requires. SIE
evaluates only whether the current EMD supplies those requirements with
an applicable state (`true`, `false` or `unknown` as supplied by the EMD
contract). SIE does not interpret Filter-specific thresholds or
boundaries. Those belong to the Filter.

Applicability evaluation is transient. SIE does not retain a persistent
claim that a Filter is compatible with a provider/model because a later
EMD may differ.

At first Ask the raw client request becomes available. SIE recognises
the client representation and revalidates the selected configuration
against the current EMD and the now-known representation path.

Successful first-Ask validation results in:

1.  materialisation of the immutable Session Execution Plan; and
2.  creation of a minimal hot `ExecutionInstance` attached to
    `session_id`.

The Execution Instance contains only the live resolved machinery SIE
requires for subsequent execution, such as resolved component
instances/references and request/response/loopback paths. It is not a
duplicate of the Session Execution Plan and does not retain the EMD
merely as model knowledge.

Subsequent interactions provide `session_id` plus interaction material.
SIE uses the existing Execution Instance rather than rediscovering
components or re-evaluating the EMD.

A missing provider representation remains incomplete configuration, not
the Unknown-client path.

------------------------------------------------------------------------

# 8. Work Stage IP-01.1 --- SIE Foundation Contracts

Implement the minimum contracts required to establish SIE as an
extensible interaction framework before implementing concrete
translation behaviour.

IP-01.1 deliberately does **not** create a generic decision framework,
provenance framework, model-characteristic ontology, or duplicate
session-facts object.

The initial foundation should establish:

-   generic component identity and implementation/API version metadata;
-   self-description/manifest structure;
-   generic representation identity without hard-coded representation
    values;
-   Base Adapter contract shape;
-   Specialised Adapter contract shape;
-   Filter contract shape;
-   minimal EMD structural contract sufficient for requirement
    availability checks;
-   explicit Filter execution-mode declaration, including whether a
    Filter requires a private model interaction;
-   Core ↔ SIE interaction boundary;
-   Adapter IN/OUT semantics relative to CIM;
-   session-scoped Execution Instance contract/lifecycle;
-   `session_id` ownership/reference;
-   `filter_execution_id` ownership for Filter invocation; and
-   only those base errors demonstrated by the foundation
    implementation.

A Base Adapter definition must be able to declare the representation it
owns and the operations by which that representation maps to and from
CIM. SIE must not contain hard-coded OpenAI, Anthropic or other
representation identities.

A Filter definition must be able to declare required EMD attributes and
its native/output representation. The framework determines whether
required information is available; the Filter owns the interpretation of
values, thresholds and boundaries.

A Filter that requires a private model interaction must declare that
structural execution requirement. The Filter must not call the provider
directly. SIE retains control of the Filter invocation and uses the
Moderari Core boundary to perform the provider interaction and return
the corresponding response to the same Filter invocation.

### Acceptance

-   foundation contracts instantiate without any running Lumen service;
-   framework code contains no concrete OpenAI, Anthropic, Qwen, System
    Prompt or Cognition knowledge;
-   representation identities can be contributed by discovered
    implementations;
-   a dummy Base Adapter can describe its representation without
    changing SIE;
-   a dummy Filter can declare required EMD attributes without changing
    SIE;
-   Filter applicability is reducible to current EMD requirement
    availability;
-   no applicability result is persisted as provider/model knowledge;
-   a Filter can declare whether it requires private model interaction;
-   SIE has a defined Core boundary through which such private
    interaction can be executed;
-   a session-scoped Execution Instance can be created, retrieved by
    `session_id`, and destroyed;
-   the Execution Instance does not duplicate the EMD or Session
    Execution Plan;
-   no generic `decisions.py` or provenance framework is required.

------------------------------------------------------------------------

# 9. Work Stage IP-01.2 --- Representation Registry and Client Recognition

Implement the representation-recognition boundary independently from CIM
translation.

Each Lumen-controlled Base Representation Adapter should be able to
contribute recognition/validation knowledge for its published external
representation.

The Representation Resolver must return:

``` text
Known(<representation>)
```

or:

``` text
Unknown
```

It must not guess when evidence is insufficient or ambiguous.

Recognition must remain separate from CIM mapping.

### Initial recognition targets

-   OpenAI-compatible published request representation;
-   Anthropic published request representation;
-   deliberately ambiguous fixture;
-   unsupported/unknown fixture.

### Acceptance

-   OpenAI fixture is recognised as OpenAI.
-   Anthropic fixture is recognised as Anthropic.
-   ambiguous fixture returns `Unknown`.
-   unsupported fixture returns `Unknown`.
-   recognition does not invoke CIM.
-   recognition does not inspect provider/model identity to decide
    client representation.
-   a Specialised Adapter cannot make an Unknown representation known.

------------------------------------------------------------------------

# 10. Work Stage IP-01.3 --- CIM 1.0

Define the first concrete CIM schema from the published OpenAI and
Anthropic interaction semantics required by the initial Adapter use
cases.

The schema must be deliberately smaller than the union of both APIs.

Initial candidate semantic concepts are:

``` text
Interaction
├── system context
├── messages
│   ├── role
│   └── content
├── tool definitions
│   ├── name
│   ├── description
│   └── input schema
├── tool calls
│   ├── call identity
│   ├── tool identity
│   └── arguments
├── tool results
│   ├── call identity
│   └── result content
└── compatibility-critical request options
```

The final CIM 1.0 content must be derived during implementation from the
concrete OpenAI/Anthropic mappings rather than treating the illustrative
architecture schema as final.

CIM must have:

-   schema identity;
-   explicit version;
-   typed semantic objects;
-   validation;
-   clear optional/required fields; and
-   an explicit extension/evolution boundary.

### Acceptance

-   CIM instances can be constructed and validated independently.
-   CIM contains no Qwen/provider-specific concepts.
-   CIM contains no Filter concepts.
-   CIM is not exposed as a network protocol.
-   schema version is explicit.
-   unsupported semantic material cannot disappear silently during
    conversion.

------------------------------------------------------------------------

# 11. Work Stage IP-01.4 --- Base Representation Adapter Contract

Implement the Lumen-controlled Base Representation Adapter contract.

A Base Adapter must support the operations required to:

``` text
external representation → CIM
CIM → external representation
```

and declare:

-   identity;
-   implementation version;
-   Lumen extension API version;
-   external representation identity;
-   compatible CIM version(s);
-   supported direction(s); and
-   recognition/validation capability where applicable.

Base Representation Adapters are Lumen-controlled. Third-party extension
discovery must not permit a plugin to introduce a new Base
Representation Adapter.

### Acceptance

-   a Base Adapter can map external material to CIM;
-   a Base Adapter can materialise CIM into its external representation;
-   compatibility with CIM version is checked;
-   the contract contains no provider/model-specific matching;
-   the contract can be exercised without the resolver.

------------------------------------------------------------------------

# 12. Work Stage IP-01.5 --- OpenAI Base Representation Adapter

Implement the first concrete Base Representation Adapter against the
published OpenAI interaction representation.

The first implementation should cover only the semantic concepts
required for CIM 1.0 and the acceptance scenarios.

Tests should include round-trip cases where semantically representable
content survives:

``` text
OpenAI → CIM → OpenAI
```

Round-trip equality should be semantic rather than dependent on
irrelevant JSON field ordering.

### Acceptance

-   supported OpenAI request material maps to valid CIM;
-   CIM material maps back to valid OpenAI representation;
-   tool definitions/calls/results required by CIM 1.0 survive
    semantically;
-   unsupported documented semantics are reported rather than silently
    discarded.

------------------------------------------------------------------------

# 13. Work Stage IP-01.6 --- Anthropic Base Representation Adapter

Implement Anthropic as the second Base Representation Adapter.

This stage is important because it proves that CIM is a genuine semantic
bridge rather than an OpenAI-shaped intermediate object.

Required paths include:

``` text
Anthropic → CIM → Anthropic
OpenAI → CIM → Anthropic
Anthropic → CIM → OpenAI
```

### Acceptance

-   supported Anthropic material maps to valid CIM;
-   CIM material maps to valid Anthropic representation;
-   OpenAI ↔ Anthropic translation operates without either Adapter
    containing direct knowledge of the other;
-   interoperability loss is surfaced explicitly.

------------------------------------------------------------------------

# 14. Work Stage IP-01.7 --- Adapter Registry and Discovery

Implement restart-based Adapter discovery and the internal Adapter
Registry.

The registry contains:

``` text
Lumen Base Representation Adapters
Specialised Adapters
```

Discovery should support external extension packages through a
configured extension location.

Initial extension manifest validation should cover:

-   extension type;
-   identity;
-   implementation version;
-   extension API version;
-   entry point;
-   base representation specialised;
-   provider;
-   model/family matching key; and
-   configuration metadata where required.

Duplicate Specialised Adapter provider+model keys must cause
registry/startup failure.

### Acceptance

-   valid extensions are discovered;
-   malformed manifests are rejected;
-   incompatible extension API versions are rejected;
-   duplicate Specialised Adapter keys fail deterministically;
-   third-party manifests cannot register a new Base Representation
    Adapter;
-   discovery requires restart only;
-   no provider/model-specific extension is hardcoded into Core.

------------------------------------------------------------------------

# 15. Work Stage IP-01.8 --- Deterministic Adapter Resolver

Implement the architectural resolution order exactly.

For normal execution:

``` text
1. recognise client representation
2. if Unknown:
      No Filters       → No Adapter / pass-through
      Filters selected → reject
3. require configured provider representation
4. compare client and provider+model representations
5. if the representations are the same:
      exact provider+model Specialised Adapter
      else provider+derived-family Specialised Adapter
      else No Adapter / pass-through
6. if the representations differ:
      Base Representation Adapter A -> CIM -> Base Representation Adapter B
7. otherwise reject known incompatibility
```

Family derivation is mechanical:

``` text
qwen2.5-coder:14b
→ qwen2.5-coder
```

No priority, scope, specificity or stacking system is to be introduced.

### Adapter Disabled

The normal execution Adapter Enabled/Disabled control must be
represented explicitly.

Disabled means no normal client↔provider translation is performed.

It does **not** disable mandatory Filter loopback.

The exact integrated user-control behaviour belongs later, but IP-01
must prove this distinction.

### Acceptance

Every resolution branch above has a deterministic unit test.

In particular:

-   Specialised Adapter eligibility requires the same Base Protocol on
    the client, provider+model and Specialised Adapter;
-   within that same-protocol branch, exact beats family;
-   family beats same-representation pass-through;
-   a resolved Specialised Adapter is the single effective Adapter for
    the same-protocol interaction and does not stack with a second Base
    Adapter;
-   same representation short-circuits CIM when no Specialised Adapter
    applies;
-   known differing representations use only the Base/CIM/Base path when
    available;
-   known incompatible path rejects;
-   Unknown client + no Filters passes unchanged;
-   Unknown client + Filters rejects;
-   missing provider representation is an incomplete-configuration
    failure;
-   Disabled normal Adapter processing does not disable loopback.

------------------------------------------------------------------------

# 16. Work Stage IP-01.9 --- Specialised Adapter Contract

Implement the Specialised Adapter extension contract.

A Specialised Adapter:

-   specialises an existing Lumen Base Representation Adapter;
-   does not define a new interaction representation;
-   does not extend CIM;
-   declares provider/model matching;
-   may match exact model or derived family;
-   owns correction of provider/model deviations;
-   owns any loss introduced by its override behaviour.

The initial contract should allow a Specialised Adapter to intercept the
appropriate conversion/materialisation point without requiring
model-specific branches in Core.

The exact override mechanism was deliberately deferred by the
architecture and is therefore a genuine implementation design decision
inside this stage.

The chosen mechanism must be documented before the Qwen migration is
considered complete.

### Acceptance

-   a Specialised Adapter can alter behaviour for a known provider/model
    deviation;
-   Core contains no `if qwen`, `if ollama`, etc.;
-   the Specialised Adapter cannot register a new representation;
-   the Specialised Adapter cannot modify the CIM schema;
-   exact/family matching uses registry metadata only;
-   only one effective Specialised Adapter is used for an execution.

------------------------------------------------------------------------

# 17. Work Stage IP-01.10 --- Qwen Specialised Adapter

Migrate the existing Qwen compatibility behaviour into the Specialised
Adapter architecture.

Before migration:

1.  inspect the current Moderari Qwen translator;
2.  identify the exact deviation(s) it compensates for;
3.  separate published OpenAI semantics from Qwen-specific behaviour;
4.  create regression fixtures from current known behaviour.

Then implement the Qwen Specialised Adapter without carrying old
architectural coupling into the new framework.

### Acceptance

-   existing required Qwen compatibility behaviour is reproduced;
-   Qwen-specific logic exists only in the Specialised Adapter;
-   removing the Qwen extension removes Qwen-specific compensation
    without affecting Base OpenAI behaviour;
-   the Qwen Adapter resolves by provider/model metadata;
-   family matching works for applicable Qwen model variants;
-   no Qwen concept appears in CIM.

------------------------------------------------------------------------

# 18. Work Stage IP-01.11 --- Normal Adapter Execution Path

Implement execution of the resolved normal client→provider path.

Possible effective paths are:

``` text
No Adapter / pass-through

Specialised Adapter path

Base Adapter:
Client Representation
    → CIM
    → Provider Representation
```

The execution result must carry generic metadata describing:

-   client representation;
-   provider representation;
-   Adapter state;
-   effective Adapter identity/version where applicable;
-   CIM version where used;
-   Specialised Adapter identity/version where applicable;
-   loss/incompatibility information; and
-   final provider-bound representation.

This metadata is an internal result in IP-01. Vestigare integration is
later.

### Acceptance

-   pass-through does not introduce CIM;
-   same-representation No Adapter does not normalise through CIM;
-   Base translation uses CIM;
-   Specialised path reports its effective component identity/version;
-   execution output and decision metadata can be inspected
    independently.

------------------------------------------------------------------------

# 19. Work Stage IP-01.12 --- Filter Contract and Registry

Implement the self-describing Filter contract and restart-based Filter
discovery.

A Filter declares:

-   identity;
-   implementation version;
-   extension API version;
-   description;
-   entry point;
-   execution stage;
-   output representation;
-   positive model requirements;
-   configuration schema.

Filters operate only in the to-model direction.

Filters do not:

-   consume CIM;
-   produce CIM;
-   own model truth;
-   classify the client representation;
-   transform the client-visible response.

### Acceptance

-   independently packaged Filters can be discovered;
-   invalid manifests are rejected;
-   unavailable Filters can be identified;
-   Filter code is not hardcoded into the framework;
-   Filter contract contains an explicit external output representation;
-   Filter API contains no CIM dependency.

------------------------------------------------------------------------

# 20. Work Stage IP-01.13 --- Filter Requirement Evaluation

Implement transient Filter applicability evaluation against the current
EMD.

A Filter declares only the EMD attributes it requires. SIE determines
whether those requirements are currently supplied/satisfied by the
authoritative EMD.

SIE does not define the semantic meaning of an EMD attribute and does
not evaluate Filter-specific numeric/string boundaries. If a Filter
requires an attribute such as `context_window`, the Filter itself
interprets the supplied value when its own implementation requires such
interpretation.

The applicability result is not persisted as model knowledge. It is
evaluated during configuration and revalidated at first Ask because the
EMD and installed component set may have changed and the client
representation is only then known.

### Acceptance

-   required EMD attribute available/satisfied → Filter may remain
    applicable;
-   required EMD attribute false → not applicable;
-   required EMD attribute Unknown/missing → not applicable;
-   SIE contains no characteristic-specific boundary rules;
-   Filter does not query provider/model runtime;
-   SIE does not retain model↔Filter compatibility after evaluation;
-   first Ask revalidates the selected Filter against the current EMD.

------------------------------------------------------------------------

# 21. Work Stage IP-01.14 --- Filter Invocation and Private Model Interaction

Implement generic Filter invocation ownership.

For every Filter invocation the Filter Framework creates:

``` text
filter_execution_id
```

The framework, not the Filter, owns this identity.

A Filter declares its execution mode. A simple transformation Filter
completes without a private model round-trip. A Filter requiring model
interaction emits a private Ask through its SIE execution context.

SIE remains in control of the invocation. It passes the provider-bound
private interaction to Moderari Core using the Core ↔ SIE contract;
Moderari Core owns provider transport/execution; the returned provider
response is passed back through SIE to the same `filter_execution_id`
and Filter invocation.

The Filter must not know provider endpoints, Praebere lifecycle, CIM
routing or the concrete Adapter path.

### Acceptance

-   every Filter invocation receives a unique `filter_execution_id`;
-   a transform-only Filter requires no provider round-trip;
-   a model-interaction Filter can request a private Ask without calling
    the provider directly;
-   Moderari Core can execute the private provider interaction through
    the defined SIE boundary;
-   the response returns to the same Filter invocation;
-   Adapter/CIM compatibility processing remains owned by SIE.

------------------------------------------------------------------------

# 22. Work Stage IP-01.15 --- Filter Execution and Mandatory Loopback

Implement Filter execution with one authoritative loopback
implementation inside SIE.

Moderari Core must not contain Filter-loopback rules.

``` text
Filter
  │
  └── Filter-produced material in Filter native representation
          │
          ▼
         SIE
          │
          ├── representation == client representation
          │       → no translation
          │
          └── representation differs
                  → source Base Adapter
                  → CIM
                  → client Base Adapter
                  → client representation
```

Loopback translation is mandatory when representations differ and
remains active even when normal client↔provider Adapter processing is
Disabled.

For Filters requiring a private model interaction, SIE also owns the
reverse compatibility path required to return the provider response to
the Filter's native representation before Filter execution continues.

Only the Filter's final materialised output is incorporated as its
result. Transient representation/CIM objects are execution mechanics.

### Acceptance

-   Filter output already in client representation requires no loopback;
-   differing known representations use Base Adapter → CIM → Base
    Adapter;
-   loopback remains active with normal Adapter state Disabled;
-   Unknown client representation + selected Filter rejects before
    execution;
-   Moderari Core contains no duplicate loopback logic;
-   private model response returns to the Filter in the representation
    its contract expects;
-   transient CIM is not exposed as Filter output.

------------------------------------------------------------------------

# 23. Work Stage IP-01.16 --- Initial Test Filter

Before migrating the real System Prompt Filter, implement a deliberately
simple test Filter.

Its purpose is to prove:

-   discovery;
-   configuration;
-   requirement evaluation;
-   execution identity;
-   output representation declaration;
-   transformation;
-   loopback;
-   Final Filter Output; and
-   provenance.

The test Filter should perform an unmistakable but simple intentional
transformation so framework defects are easy to diagnose.

It should not depend on a live model.

### Acceptance

The complete Filter framework can be tested without System Prompt
semantics or private model calls.

------------------------------------------------------------------------

# 24. Work Stage IP-01.17 --- System Prompt Filter Migration

Once the generic Filter framework is proven, migrate existing System
Prompt behaviour into the new Filter architecture.

Moderari Core must have no implicit default System Prompt.

System Prompt behaviour must exist only when the Filter is explicitly
configured.

The migration should begin with an inspection of current Moderari
behaviour to distinguish reusable implementation from legacy coupling.

### Acceptance

-   no Filter selected → no Lumen default System Prompt;
-   System Prompt Filter selected → configured prompt material is
    produced;
-   output is materialised in the client representation;
-   System Prompt-specific logic does not appear in Filter Framework
    Core;
-   behaviour is testable without a live model.

------------------------------------------------------------------------

# 25. Work Stage IP-01.18 --- Cognition Filter Contract Skeleton

The architecture identifies Cognition as the second current built-in
Filter, but its full behaviour need not block the Adapter/CIM
foundation.

IP-01 should at minimum prove that the framework can represent a Filter
that:

-   has positive model/context requirements;
-   declares that it requires private model interaction;
-   produces external-representation interaction material;
-   keeps the private Ask/Response under one `filter_execution_id`; and
-   receives the private response back from SIE without knowing provider
    transport.

If existing Cognition behaviour is sufficiently stable and reusable,
migration may proceed in IP-01. Otherwise a contract-level test
implementation is sufficient and full migration can become a subsequent
work package.

This decision should be made after inspecting the existing
implementation rather than assumed now.

------------------------------------------------------------------------

# 26. Work Stage IP-01.19 --- Session-Scoped Execution Instance

Implement the hot runtime object created after successful first-Ask
materialisation.

The Execution Instance is keyed by `session_id` and contains only live
resolved machinery needed by SIE to execute subsequent interactions. It
is not an alternative Session Execution Plan and must not become a
model-knowledge cache.

It may hold resolved Adapter/Filter instances or references and
pre-resolved request, response and loopback paths where those are
required for efficient execution.

Lifecycle:

``` text
configuration
    → transient availability evaluation

first Ask
    → recognise client representation
    → revalidate current EMD/configuration
    → resolve paths/components
    → materialise immutable Session Execution Plan
    → create hot Execution Instance

subsequent Ask/Response
    → session_id
    → existing Execution Instance
    → execute resolved path

session end
    → destroy Execution Instance
```

### Acceptance

-   first Ask creates exactly one hot Execution Instance for the
    session;
-   subsequent interactions reuse it without repeated EMD evaluation;
-   it contains only execution-required runtime state;
-   it does not duplicate the Session Execution Plan;
-   it does not retain EMD/model knowledge merely for reference;
-   session end removes the instance and its session-local component
    state.

------------------------------------------------------------------------

# 27. Work Stage IP-01.20 --- Published-Semantic Loss Handling

Implement an explicit result mechanism for published-representation
interoperability loss.

The architecture intentionally leaves the final policy open. IP-01
therefore should not prematurely define one universal policy.

It must, however, make loss impossible to hide.

Minimum implementation:

``` text
TranslationResult
├── success
├── incompatibility
└── semantic_loss
       ├── source semantic
       ├── target representation
       └── explanation/identity
```

Tests may initially treat semantic loss as a rejected translation unless
an individual scenario explicitly permits it.

Provider/model-specific override loss remains the responsibility of the
Specialised Adapter and must be reported separately from Base/CIM
interoperability loss.

### Acceptance

-   documented source semantics cannot silently disappear;
-   Base/CIM loss and Specialised Adapter override loss are
    distinguishable;
-   tests can assert the exact loss boundary.

------------------------------------------------------------------------

# 29. Work Stage IP-01.21 --- Standalone Scenario Harness

Build a lightweight harness around the interaction engine.

The harness is not a replacement client or temporary Lumen service.

It exists to make architectural scenarios easy to execute and inspect.

A scenario should be able to declare:

``` yaml
provider:
  id: ollama
  representation: openai
  model: qwen2.5-coder:14b

model_facts:
  ...

adapter_state: enabled

filters:
  ...

client_request:
  fixture: anthropic/tool-call.json
```

and return an inspectable result containing:

-   recognition result;
-   resolved Adapter path;
-   Filter applicability;
-   Filter execution(s);
-   loopback path(s);
-   Final Filter Output(s);
-   normal provider translation path;
-   final provider-bound interaction;
-   component identities/versions;
-   loss/failure information.

The harness should be usable both from automated tests and a simple
developer-facing command line.

------------------------------------------------------------------------

# 29. Minimum Acceptance Scenario Matrix

The following scenarios form the minimum IP-01 acceptance suite.

  ---------------------------------------------------------------------
  Scenario                           Expected result
  ---------------------------------- ----------------------------------
  OpenAI client → OpenAI provider,   No Adapter
  no Specialised Adapter             

  Anthropic client → Anthropic       No Adapter
  provider                           

  OpenAI client → Anthropic provider Base translation through CIM

  Anthropic client → OpenAI provider Base translation through CIM

  Unknown client → provider, no      Pass through unchanged
  Filters                            

  Unknown client + Filter            Reject

  Known differing representations    Reject
  with missing Base path             

  Missing provider representation    Incomplete configuration

  Exact Specialised Adapter match    Exact Adapter used

  Exact missing, family Specialised  Family Adapter used
  Adapter match                      

  Exact + family both exist          Exact used

  Specialised Adapter + same         Specialised Adapter used
  representation                     

  Same representation, no            No Adapter; no CIM
  Specialised Adapter                

  Duplicate Specialised Adapter      Startup/registry failure
  registry key                       

  Normal Adapter Disabled, no        No normal translation
  Filters                            

  Normal Adapter Disabled + Filter   Loopback still executes
  requiring loopback                 

  OpenAI-native Filter + OpenAI      No loopback
  client                             

  OpenAI-native Filter + Anthropic   Loopback through CIM
  client                             

  Filter positive requirement = true Applicable

  Filter positive requirement =      Not applicable
  false                              

  Filter positive requirement =      Not applicable
  Unknown                            

  Filter unavailable                 Profile/config invalid

  Published semantic cannot map to   Explicit loss/incompatibility
  target                             

  Qwen exact/family case             Specialised behaviour, no Core
                                     Qwen branch

  Filter invocation                  unique `filter_execution_id`

  Filter-produced material after     Final output in client
  loopback                           representation

  Client-origin and Filter-origin    provenance distinct internally
  material                           
  ---------------------------------------------------------------------

------------------------------------------------------------------------

# 30. Testing Layers

## 29.1 Unit Tests

Cover:

-   representation recognition;
-   family derivation;
-   registry uniqueness;
-   manifest validation;
-   CIM validation;
-   each Base Adapter mapping;
-   requirement evaluation;
-   resolver branches;
-   Filter execution identity;
-   loss reporting.

## 29.2 Contract Tests

Every Base Adapter must run against the same Base Adapter contract
suite.

Every Specialised Adapter must run against the same Specialised Adapter
contract suite.

Every Filter must run against the same Filter contract suite.

This makes third-party extension compliance testable.

## 29.3 Translation Tests

Use fixture pairs and semantic assertions for:

``` text
OpenAI → CIM
CIM → OpenAI
Anthropic → CIM
CIM → Anthropic
OpenAI → CIM → Anthropic
Anthropic → CIM → OpenAI
```

## 29.4 Architectural Negative Tests

Negative tests are first-class requirements.

Examples:

-   Filter imports/depends upon CIM contract;
-   third-party Base Adapter registration;
-   duplicate specialised key;
-   ambiguous representation guessed as known;
-   Specialised Adapter selected while client representation is Unknown;
-   Filters allowed with Unknown client representation;
-   loopback bypassed because normal Adapter state is Disabled;
-   silent semantic loss;
-   model-specific Core branch.

Where practical these should fail mechanically rather than depend solely
on code review.

## 29.5 Regression Tests

Before migrating current Qwen/System Prompt behaviour, capture existing
required behaviour as fixtures.

The new implementation must reproduce required behaviour without
reproducing obsolete architecture.

------------------------------------------------------------------------

# 31. Implementation Order

Recommended coding order:

``` text
IP-01.1   SIE foundation contracts
    ↓
IP-01.2   Representation recognition
    ↓
IP-01.3   CIM 1.0
    ↓
IP-01.4   Base Adapter contract
    ↓
IP-01.5   OpenAI Base Adapter
    ↓
IP-01.6   Anthropic Base Adapter
    ↓
IP-01.7   Adapter registry/discovery
    ↓
IP-01.8   Deterministic Adapter resolver
    ↓
IP-01.9   Specialised Adapter contract
    ↓
IP-01.10  Qwen migration
    ↓
IP-01.11  Normal execution path
    ↓
IP-01.12  Filter contract/registry
    ↓
IP-01.13  transient Filter requirement evaluation
    ↓
IP-01.14  Filter invocation/private model interaction
    ↓
IP-01.15  Filter execution + mandatory SIE loopback
    ↓
IP-01.16  Test Filter
    ↓
IP-01.17  System Prompt migration
    ↓
IP-01.18  Cognition contract/migration decision
    ↓
IP-01.19  session-scoped Execution Instance
    ↓
IP-01.20  explicit loss handling
    ↓
IP-01.21  complete standalone scenario harness
```

This order may be implemented in small vertical slices where useful, but
later stages must not force architectural coupling back into earlier
layers.

------------------------------------------------------------------------

# 32. Existing Moderari Code Inspection Points

Existing Moderari code should be inspected selectively rather than
treated as the design source.

The first inspection should identify:

1.  current Qwen translation behaviour;
2.  current System Prompt injection/replacement behaviour;
3.  current Cognition behaviour;
4.  existing context manipulation useful to Filters;
5.  existing request/response models that may be reusable;
6.  existing provider/model conditionals that must disappear;
7.  existing tests/fixtures that capture useful behaviour.

Each piece should be classified as:

``` text
RETAIN
    implementation already fits the new responsibility

ADAPT
    useful implementation but coupled to old boundaries

MIGRATE
    behaviour belongs in a new Adapter/Filter extension

DELETE
    obsolete under the new architecture

DEFER
    belongs to later Stack integration
```

No existing code is retained merely to preserve the old path.

------------------------------------------------------------------------

# 33. Deliverables

IP-01 should produce:

1.  standalone interaction-engine package;
2.  Representation Resolver and registry;
3.  CIM 1.0 schema and typed implementation;
4.  OpenAI Base Representation Adapter;
5.  Anthropic Base Representation Adapter;
6.  Adapter registry/discovery;
7.  deterministic Adapter resolver;
8.  Specialised Adapter extension contract;
9.  migrated Qwen Specialised Adapter;
10. normal Adapter execution engine;
11. Filter registry/discovery;
12. Filter requirement evaluator;
13. Filter execution framework;
14. mandatory client-representation loopback;
15. Filter invocation identity/private-interaction structures;
16. simple framework Test Filter;
17. migrated System Prompt Filter;
18. Cognition Filter migration decision/contract proof;
19. explicit interoperability-loss result mechanism;
20. standalone developer harness;
21. automated unit, contract, regression and architectural acceptance
    tests;
22. concise developer documentation for creating a Specialised Adapter;
23. concise developer documentation for creating a Filter; and
24. an integration contract describing the facts future
    Praebere/Moderari session integration must supply.

------------------------------------------------------------------------

# 34. Definition of Done

IP-01 is complete when all of the following are true.

### Independence

The entire acceptance suite runs without the Lumen Stack or a live
provider.

### Representation

Moderari can positively recognise supported client representations and
return `Unknown` without guessing.

### CIM

OpenAI and Anthropic published interaction semantics required by the
supported scenarios can be represented and translated through a
versioned CIM.

### Adapter Resolution

All architectural resolution branches are deterministic and tested.

### Specialisation

Qwen-specific compatibility is implemented as a Specialised Adapter with
no Qwen-specific Core logic.

### Filters

A Filter can be independently discovered, validated, checked for
applicability and executed without CIM knowledge.

### Loopback

Filter output can be materialised into the recognised client
representation through mandatory Adapter loopback independently of the
normal Adapter Enabled/Disabled state.

### Evidence

The engine exposes component identity/version, `filter_execution_id`,
translation/loss information generically without depending on Vestigare.

### Failure Behaviour

Unknown, incompatible, unavailable, duplicate and lossy cases are
explicit and testable.

### Extension Boundary

A new compliant Specialised Adapter or Filter can be added without
changing Moderari Core.

### Integration Readiness

The standalone engine has a clear input/output contract suitable for
subsequent Praebere and full Moderari session integration.

------------------------------------------------------------------------

# 35. Exit Point and Next Work Package

IP-01 deliberately stops before production Stack integration.

At completion, the next major work package should begin with
**Praebere**, using the proven standalone engine to define exactly which
authoritative session/model facts Moderari requires.

That work should establish:

-   per-session provider/model reservation;
-   provider interaction representation;
-   Effective Model Definition;
-   characteristic provenance;
-   model lifecycle/readiness; and
-   the configuration-time exchange through which Moderari evaluates
    Filter applicability.

The important change from the earlier high-level plan is that Praebere
will then be implemented against a **working Moderari interaction
contract**, rather than against an interaction framework that exists
only on paper.

------------------------------------------------------------------------

# 36. IP-01 Guiding Test

A concise test of whether IP-01 has maintained the architecture is:

> Given discovered/self-describing Adapter and Filter implementations,
> an authoritative current EMD, selected session configuration and a raw
> first client request, can SIE determine whether the configuration is
> usable, resolve the required representation/Filter/loopback paths,
> materialise the execution configuration into a minimal hot
> session-scoped Execution Instance, and thereafter process interactions
> without re-reading model knowledge or knowing the semantics of any
> concrete Adapter or Filter?

A second boundary test is equally important:

> Can Moderari Core treat SIE as the single interaction-processing
> enter/exit point, including private Filter model interactions and
> mandatory loopback, without containing protocol-, model- or
> Filter-specific transformation logic?

If yes, the foundation is ready for Praebere and full Stack integration.

## 02026-10-06 Specialised Adapter Pair-Replacement Clarification

### Architectural Rule

A Specialised Adapter is a same-protocol specialisation of an existing
Base Protocol Adapter. It is eligible only when the recognised client
protocol, the Specialised Adapter's Base Protocol, and the
provider+model protocol are the same, in addition to the required
provider/model or family match.

When such a Specialised Adapter is resolved, it is architecturally the
effective **Adapter A and Adapter B** for that same-protocol
interaction. SIE does not compose the Specialised Adapter with a second
Base Adapter across CIM.

Conceptually:

``` text
same protocol, no specialisation

Protocol X payload --------------------------> Protocol X payload
                    pass-through
```

``` text
same protocol, Specialised Adapter resolved

Protocol X payload
        |
        v
+---------------------------+
|   Specialised Adapter     |
|                           |
|   effective Adapter A     |
|   effective Adapter B     |
|                           |
|   may use Base Adapter    |
|   and CIM internally      |
+---------------------------+
        |
        v
Protocol X payload
```

By contrast, differing protocols continue to use the ordinary Base
Adapter bridge:

``` text
Protocol A payload
        |
        v
Base Adapter A IN
        |
        v
       CIM
        |
        v
Base Adapter B OUT
        |
        v
Protocol B payload
```

Therefore:

> **Base Protocol Adapter pairs plus CIM provide cross-protocol
> interoperability. A resolved Specialised Adapter replaces both sides
> of the Adapter pair for a same-protocol specialised interaction.**

### Specialised Adapter Execution Semantics --- Current Interpretation

The exact internal implementation of a Specialised Adapter remains
deliberately open for IP-01 implementation and testing.

The current working interpretation is:

1.  every invocation enters the Specialised Adapter as a payload in its
    inherited Base Protocol;
2.  the Specialised Adapter may recognise and correct
    provider/model-specific deviations while processing that incoming
    payload;
3.  the corrected semantic interaction may be represented internally as
    CIM using the inherited Base Adapter contract;
4.  the inherited Base Adapter materialisation can then return the
    normal Base Protocol payload; and
5.  if the incoming payload requires no specialised correction, the
    implementation may preserve/pass through the Base Protocol
    interaction as appropriate.

This is intended to allow one Specialised Adapter implementation to
handle deviations observable in either interaction flow without
requiring SIE or the Adapter manifest to describe `to_model`,
`from_model`, client-side or provider-side transformation directions.

For the current Qwen case, the known deviation is present in
model-produced OpenAI-compatible payload material, particularly
textual/tool-call material. A Qwen Specialised Adapter can recognise
that deviation when the protocol payload enters the Adapter,
canonicalise/correct it, and rely on the Base OpenAI behaviour to
materialise the normal OpenAI-compatible payload.

The implementation mechanism is **not yet frozen**. In particular, IP-01
must test how specialised IN behaviour, inherited Base IN/OUT behaviour,
internal CIM use and pass-through interact so that an internal
conversion cannot accidentally invoke an opposing specialised override
or reverse a correction.

The architecture is frozen only at the following level:

> **A Specialised Adapter is one same-protocol effective Adapter
> occupying the architectural roles that Adapter A and Adapter B would
> otherwise occupy. Its internal use of Base Adapter operations and CIM
> is an implementation concern and remains open to further
> interpretation during IP-01.**

A Specialised Adapter does not expose its internal CIM traversal as an
inter-Adapter CIM boundary, and SIE must not route CIM from another
Adapter into a Specialised Adapter. Cross-protocol interaction is
handled by Base Protocol Adapters, not by Specialised Adapters.
